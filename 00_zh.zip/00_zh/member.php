<?php
/**
 * WEEDCMS 会员页面
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月08日
*/
require_once('includes/global.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once('includes/front.php');
if($config['member_state']=='no'){
	message(array('text'=>$language['member_sysytem_is_close'],'link'=>'./'));
}
$action=isset($_GET['action'])?$_GET['action']:'';
//AJAX检查会员邮件地址
if($action=='check_member_mail'){
	check_request();
	$member_mail=empty($_GET['member_mail'])?'':trim($_GET['member_mail']);
	if(!is_email($member_mail)){
		echo('1');
		exit;
	}
	$count=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_mail='".$member_mail."'");
	if($count>0){
		echo('1');
	}else{
		echo('0');
	}
	exit;
}
//AJAX检查会员昵称
if($action=='check_member_nickname'){
	check_request();
	$member_nickname=empty($_GET['member_nickname'])?'':trim($_GET['member_nickname']);
	$count=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_nickname='".$member_nickname."'");
	if($count>0){
		echo('1');
	}else{
		echo('0');
	}
	exit;
}
//AJAX导出登陆界面
if($action=='login'){
	check_request();
	$smarty=new smarty();smarty_header();
	$smarty->display('ajax_member_login.html');
}
//AJAX处理登陆
if($action=='login_ok'){
	check_request();
	$member_mail=empty($_GET['member_mail'])?'':trim(addslashes($_GET['member_mail']));
	$member_password=empty($_GET['member_password'])?'':password($_GET['member_password']);
	if(empty($member_mail)){
		exit('error:mail_is_empty');
	}
	if(!is_email($member_mail)){
		exit('error:mail_is_error');
	}
	if(empty($member_password)){
		exit('error:password_is_empty');
	}
	$row=$db->getone("SELECT * FROM ".$db_prefix."member WHERE member_mail='".$member_mail."' and member_password='".$member_password."'");
	if($row){
		if($row['member_validation']==0){
			exit('error:account_is_not_activate');
		}
		if($row['member_state']==0){
			exit('error:account_is_lock');
		}
		$_SESSION['member_id']=$row['member_id'];
		$_SESSION['member_mail']=$row['member_mail'];
		$_SESSION['member_nickname']=$row['member_nickname'];
		$_SESSION['member_photo']=$row['member_photo'];
		$_SESSION['group_id']=$row['group_id'];
		$update=array();
		$update['member_last_time']=time();
		$update['member_last_ip']=get_ip();
		$db->update($db_prefix."member",$update,"member_mail='".$member_mail."'");
		clear_cache();
	}else{
		exit('error:login_failed');
	}
}
//AJAX导出注册界面
if($action=='register'){
	check_request();
	$smarty=new smarty();smarty_header();
	$smarty->display('ajax_member_register.html');
}
//AJAX处理注册
if($action=='register_ok'){
	check_request();
	$member_mail=empty($_GET['member_mail'])?'':trim(addslashes($_GET['member_mail']));
	$member_password=empty($_GET['member_password'])?'':trim(addslashes($_GET['member_password']));
	$member_password_confirm=empty($_GET['member_password_confirm'])?'':trim(addslashes($_GET['member_password_confirm']));
	$member_safecode=empty($_GET['member_safecode'])?'':trim(addslashes($_GET['member_safecode']));
	$member_nickname=empty($_GET['member_nickname'])?'':trim(addslashes($_GET['member_nickname']));
	$member_state=empty($_GET['member_state'])?0:intval($_GET['member_state']);
	if(empty($member_mail)){
		exit('error:mail_is_empty');
	}
	if(!is_email($member_mail)){
		exit('error:mail_is_error');
	}
	$count=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_mail='".$member_mail."'");
	if($count>0){
		exit('error:mail_is_occupy');
	}
	if(empty($member_password)){
		exit('error:password_is_empty');
	}
	if($member_password!=$member_password_confirm){
		exit('error:password_is_error');
	}
	if(empty($member_safecode)){
		exit('error:safecode_is_empty');
	}
	if(empty($member_nickname)){
		exit('error:nickname_is_empty');
	}
	$count=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_nickname='".$member_nickname."'");
	if($count>0){
		exit('error:nickname_is_occupy');
	}
	$insert=array();
	$insert['member_mail']=$member_mail;
	$insert['member_password']=password($member_password);
	$insert['member_safecode']=password($member_safecode);
	$insert['member_nickname']=$member_nickname;
	$insert['member_name']='';
	$insert['member_sex']=0;
	$insert['member_birthday']=0;
	$insert['member_phone']='';
	$insert['member_photo']='';
	$insert['member_from']='';
	$insert['member_other']='';
	if($config['member_validation_state']=='yes'){
		$key=md5($member_mail.$member_password);
		$insert['member_validation']=0;
		$insert['member_validation_key']=$key;
	}else{
		$insert['member_validation']=1;
		$insert['member_validation_key']='';
	}
	$insert['member_state']=1;
	$insert['group_id']=0;
	$insert['member_join_time']=$_SERVER['REQUEST_TIME'];
	$insert['member_last_time']=$_SERVER['REQUEST_TIME'];
	$insert['member_last_ip']=get_ip();
	$db->insert($db_prefix."member",$insert);
	clear_cache();
	if($config['member_validation_state']=='yes'){
		send_mail($member_mail,$config['smtp_user'],'Please activate the account!','<a href="'.get_position().'member.php?action=member_validation&key='.$key.'">Click!</a>');
	}else{
		$_SESSION['member_id']=$db->insert_id();
		$_SESSION['member_mail']=$member_mail;
		$_SESSION['member_nickname']=$member_nickname;
		$_SESSION['group_id']=0;
	}
}
//评论列表
if($action=='comment_list'){
	check_request();
	if(!check_login()){
		message(array('text'=>$language['please_login'],'link'=>'./'));
	}
	$comment_list=array();
	$sql="select * from ".$db_prefix."content_comment where comment_state=1 and member_id='".$_SESSION['member_id']."'";
	$count=$db->getcount($sql);
	$page_size=$config['comment_size'];
	$page_current=isset($_GET['page'])?intval($_GET['page']):1;
	$page_count		=ceil($count/$page_size);
	$page_start		=$page_current-4;
	$page_end		=$page_current+4;
	if($page_current<5){
		$page_start	=1;
		$page_end	=5;
	}
	if($page_current>$page_count-4){
		$page_start	=$page_count-8;
		$page_end	=$page_count;
	}
	if($page_start<1)$page_start=1;
	if($page_end>$page_count)$page_end=$page_count;
	$pagebar="";


	$rows=$db->getall($sql." order by comment_id desc limit ".(($page_current-1)*$page_size).",".$page_size);
	if($count>0){
			$no=$count-(($page_current-1)*$page_size);
			foreach($rows as $row){
				$comment_list[$row['comment_id']]['no']=$no;
				$comment_list[$row['comment_id']]['id']=$row['comment_id'];
				$comment_list[$row['comment_id']]['content']=encode_comment(filter_badwords($row['comment_content'],$GLOBALS['config']['site_badwords']));
				$comment_list[$row['comment_id']]['reply']=encode_comment(filter_badwords($row['comment_reply'],$GLOBALS['config']['site_badwords']));
				$comment_list[$row['comment_id']]['time']=date("Y-m-d h:i:s",$row['comment_time']);
				$comment_list[$row['comment_id']]['ip']=$row['comment_ip'];
				$comment_list[$row['comment_id']]['ip_address']=get_ip_address($row['comment_ip']);
				$comment_list[$row['comment_id']]['content_id']=$row['content_id'];
				$comment_list[$row['comment_id']]['nickname']=get_member_nickname($row['member_id']);
				$comment_list[$row['comment_id']]['member_id']=$row['member_id'];
				$comment_list[$row['comment_id']]['photo']=get_member_photo($row['member_id']);
				$comment_list[$row['comment_id']]['children']=get_content_comment_children($row['comment_id']);
				$no--;
			}
			$pagebar=pagebar("member","action=comment_list&",$page_current,$page_size,$count);
	}else{
			$pagebar='';
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('here',here('member_comment_list'));
	$smarty->assign('action',$action);
	$smarty->assign('comment_list',$comment_list);
	$smarty->assign('pagebar',$pagebar);
	$smarty->display('member.html');
}
//内容列表
if($action=='content_list'){
	check_request();
	if(!check_login()){
		message(array('text'=>$language['please_login'],'link'=>'./'));
	}
	$content_list=array();
	$sql="select * from ".$db_prefix."content where member_id='".$_SESSION['member_id']."'";
	$count=$db->getcount($sql);
	$page_size=$config['comment_size'];
	$page_current=isset($_GET['page'])?intval($_GET['page']):1;
	$page_count		=ceil($count/$page_size);
	$page_start		=$page_current-4;
	$page_end		=$page_current+4;
	if($page_current<5){
		$page_start	=1;
		$page_end	=5;
	}
	if($page_current>$page_count-4){
		$page_start	=$page_count-8;
		$page_end	=$page_count;
	}
	if($page_start<1)$page_start=1;
	if($page_end>$page_count)$page_end=$page_count;
	$pagebar="";
	$rows=$db->getall($sql." order by content_id desc limit ".(($page_current-1)*$page_size).",".$page_size);
	if($count>0){
			$no=$count-(($page_current-1)*$page_size);
			foreach($rows as $row){
				$content_list[$row['content_id']]['no']=$no;
				$content_list[$row['content_id']]['id']=$row['content_id'];
				$content_list[$row['content_id']]['channel_id']=$row['channel_id'];
				$content_list[$row['content_id']]['category_id']=$row['category_id'];
				$content_list[$row['content_id']]['category_name']=get_category_name($row['category_id']);
				$content_list[$row['content_id']]['title']=truncate($row['content_title'],50);
				$content_list[$row['content_id']]['time']=date("Y/m/d",$row['content_time']);
				$content_list[$row['content_id']]['click_count']=$row['content_click_count'];
				$content_list[$row['content_id']]['comment_count']=$row['content_comment_count'];
				$content_list[$row['content_id']]['thumb']=$row['content_thumb'];
				if(substr($row['content_thumb'],0,4)=='http'){
					$content_list[$row['content_id']]['thumb_http']=true;
				}else{
					$content_list[$row['content_id']]['thumb_http']=false;
				}
				$content_list[$row['content_id']]['text']=$row['content_text'];
				$content_list[$row['content_id']]['short_text']=truncate(strip_tags($row['content_text']),100);
				$content_list[$row['content_id']]['password']=$row['content_password'];
				$content_list[$row['content_id']]['is_new']=date("Ymd",$row['content_time'])==date("Ymd")?true:false;
				$content_list[$row['content_id']]['member_id']=$row['member_id'];
				$content_list[$row['content_id']]['url']=create_uri('content',array('id'=>$row['content_id']));
				if(empty($row['content_url'])){
					$content_list[$row['content_id']]['url']=create_uri('content',array('id'=>$row['content_id']));
					$content_list[$row['content_id']]['target']=false;
				}else{
					$content_list[$row['content_id']]['url']=$row['content_url'];
					$content_list[$row['content_id']]['target']=true;
				}
				$content_list[$row['content_id']]['category_url']=create_uri('channel',array('id'=>$row['channel_id'],'category_id'=>$row['category_id']));
				$no--;
			}
			$pagebar=pagebar("member","action=content_list&",$page_current,$page_size,$count);
	}else{
			$pagebar='';
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('here',here('member_content_list'));
	$smarty->assign('content_list',$content_list);
	$smarty->assign('pagebar',$pagebar);
	$smarty->assign('action',$action);
	$smarty->display('member.html');
}
//编辑会员
if($action=='edit_member'){
	check_request();
	if(!check_login()){
		message(array('text'=>$language['please_login'],'link'=>'./'));
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('here',here('member_edit'));
	$smarty->assign('action',$action);
	$smarty->assign('member_info',get_member_info($_SESSION['member_id']));
	$smarty->display('member.html');
}
//更新会员
if($action=='edit_member_ok'){
	check_request();
	if(!check_login()){
		message(array('text'=>$language['please_login'],'link'=>'member.php'));
	}
	$member_id=empty($_POST['member_id'])?0:intval($_POST['member_id']);
	if($member_id!=$_SESSION['member_id']){
		exit('Access Denied!');
	}

	$member_password=empty($_POST['member_password'])?'':trim(addslashes($_POST['member_password']));
	$member_password_confirm=empty($_POST['member_password_confirm'])?'':trim(addslashes($_POST['member_password_confirm']));

	$member_name=empty($_POST['member_name'])?'':trim(addslashes($_POST['member_name']));
	$member_sex=empty($_POST['member_sex'])?0:intval($_POST['member_sex']);
	$member_birthday=empty($_POST['member_birthday'])?0:strtotime($_POST['member_birthday']);
	$member_phone=empty($_POST['member_phone'])?'':trim(addslashes($_POST['member_phone']));
	$member_from=empty($_POST['member_from'])?'':trim(addslashes($_POST['member_from']));
	$member_other=empty($_POST['member_other'])?'':trim(addslashes($_POST['member_other']));

	if(!empty($member_password)){
		if($member_password!=$member_password_confirm){
			message(array('text'=>$language['password_is_error'],'link'=>''));
		}
	}
	$member_photo=upload($_FILES['member_photo'],false);
	$member_photo_old=empty($_POST['member_photo_old'])?'':trim($_POST['member_photo_old']);
	$member_photo_delete=empty($_POST['member_photo_delete'])?'':trim($_POST['member_photo_delete']);

	$update=array();
	if(!empty($member_password)){
	$update['member_password']=password($member_password);
	}
	$update['member_name']=$member_name;
	$update['member_sex']=$member_sex;
	$update['member_birthday']=$member_birthday;
	$update['member_phone']=$member_phone;
		if(!empty($member_photo)){
			if($member_photo_old!=$_SESSION['member_photo']){
				exit('Access Denied!');
			}
			$member_photo_old=str_replace('..','',$member_photo_old);
			@unlink(ROOT_PATH."/uploads/".$member_photo_old);
			$update['member_photo']=$member_photo;
			$_SESSION['member_photo']=$member_photo;
			if($config['image_thumb_open']=='yes'){
				make_thumb(ROOT_PATH.'/uploads/'.$member_photo,100,100);
			}
		}
		if(!empty($member_photo_delete)){
			if($member_photo_delete!=$_SESSION['member_photo']){
				exit('Access Denied!');
			}
			$member_photo_delete=str_replace('..','',$member_photo_delete);
			@unlink(ROOT_PATH."/uploads/".$member_photo_delete);
			$update['member_photo']='';
			$_SESSION['member_photo']='';
		}
	$update['member_from']=$member_from;
	$update['member_other']=$member_other;
	$db->update($db_prefix."member",$update,"member_id=$member_id");
	clear_cache();
	message(array('text'=>$language['member_update_success'],'link'=>'index.php'));
}
//AJAX忘记密码
if($action=='forget'){
	$smarty=new smarty();smarty_header();
	$smarty->display('ajax_member_forget.html');
}
//处理密码
if($action=='forget_ok'){
	check_request();
	$member_mail=empty($_GET['member_mail'])?'':trim(addslashes($_GET['member_mail']));
	$member_safecode=empty($_GET['member_safecode'])?'':trim(addslashes($_GET['member_safecode']));
	$count=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_mail='".$member_mail."' AND member_safecode='".password($member_safecode)."'");
	if($count>0){
		$new_password=create_password();
		$db->update($db_prefix."member",array('member_password'=>password($new_password)),"member_mail='".$member_mail."'");
		send_mail($member_mail,$config['smtp_user'],'Congratulations on your new password!','Your new password:'.$new_password.'');
		echo($language['password_is_retrieve']);
	}else{
		echo($language['password_is_failed']);
	}
}
//验证注册会员
if($action=='member_validation'){
	$key=empty($_GET['key'])?'':trim($_GET['key']);
	if($key==''){
		message(array('text'=>$language['activation_failed'],'link'=>'index.php'));
	}
	$row=$db->getcount("SELECT * FROM ".$db_prefix."member WHERE member_validation_key='$key'");
	if($row>0){
		$db->update($db_prefix."member",array('member_validation'=>1),"member_validation_key='".$key."'");
		message(array('text'=>$language['activation_success'],'link'=>'index.php'));
	}else{
		message(array('text'=>$language['activation_failed'],'link'=>'index.php'));
	}
}
//会员信息
if($action=='member_info'){
	check_request();
	$smarty=new smarty();smarty_header();
	$smarty->display('ajax_member_info.html');
	exit;
}
//用户退出
if($action=='logout'){
	check_request();
	unset($_SESSION['member_id'],$_SESSION['member_mail'],$_SESSION['member_nickname'],$_SESSION['member_photo']);
	clear_cache();
	exit;
}
?>