-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 15, 2012 at 02:24 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `en`
--

-- --------------------------------------------------------

--
-- Table structure for table `x_ad`
--

CREATE TABLE IF NOT EXISTS `x_ad` (
  `ad_id` smallint(2) NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(255) NOT NULL DEFAULT '',
  `ad_content` text NOT NULL,
  `ad_start` int(10) unsigned NOT NULL DEFAULT '0',
  `ad_end` int(10) unsigned NOT NULL DEFAULT '0',
  `ad_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ad_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_admin`
--

CREATE TABLE IF NOT EXISTS `x_admin` (
  `admin_id` tinyint(1) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `admin_permissions` text NOT NULL,
  `admin_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `x_admin`
--

INSERT INTO `x_admin` (`admin_id`, `admin_name`, `admin_password`, `admin_permissions`, `admin_state`) VALUES
(1, 'admin', 'D033E22AE348AEB5660FC2140AEC35850C4DA997', 'all', 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_admin_log`
--

CREATE TABLE IF NOT EXISTS `x_admin_log` (
  `log_time` int(10) NOT NULL DEFAULT '0',
  `log_info` varchar(255) NOT NULL,
  `log_ip` varchar(50) NOT NULL DEFAULT '',
  `log_agent` varchar(255) NOT NULL,
  `admin_id` int(4) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_admin_log`
--

INSERT INTO `x_admin_log` (`log_time`, `log_info`, `log_ip`, `log_agent`, `admin_id`) VALUES
(1326596314, '登陆系统:admin', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326597379, '删除连接:官方网站', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326597383, '删除连接:野草在线', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326597386, '删除连接:源码之家', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326597389, '删除连接:站长下载', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598363, '更新频道:商业', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598391, '更新频道:科技', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598406, '更新频道:文化', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598427, '更新频道:社会', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598612, '更新设置', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598632, '更新菜单:商业科技', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598687, '更新菜单:商业', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598726, '更新菜单:科技动态', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598743, '更新菜单:商业新闻', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598747, '删除菜单:第三分类', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598757, '更新菜单:社会文化', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598803, '更新菜单:生活健康', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598855, '更新菜单:自然体坛', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598936, '插入菜单:寻觅文化', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598956, '插入菜单:社会观察', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326598997, '更新频道:商业新闻', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599008, '更新频道:科技动态', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599021, '更新频道:文化寻觅', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599028, '更新频道:社会观察', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599136, '插入频道:生活奇趣', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599152, '插入频道:健康视角', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599188, '插入频道:自然万物', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599198, '插入频道:体坛风云', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599265, '插入菜单:生活奇趣', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599290, '插入菜单:健康视角', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599310, '插入菜单:自然万物', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599329, '插入菜单:体坛风云', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599395, '插入单页:关于我们', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599423, '更新菜单:关于我们', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599466, '删除菜单:联系我们', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599479, '更新菜单:访客留言', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599764, '插入内容:中国铁路：慢一些吧', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326599911, '插入内容:掉期交易新规则将保护大额交易客户', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600016, '插入内容:【经济学人】德国和欧元：新年不快乐', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600129, '更新内容:中国铁路：慢一些吧', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600204, '更新内容:掉期交易新规则将保护大额交易客户', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600306, '更新内容:【经济学人】德国和欧元：新年不快乐', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600476, '插入内容:三星Galaxy Note', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600510, '插入内容:三星Galaxy Note', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600521, '批量删除内容', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600767, '插入内容:怎样了解一款手机的性能', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326600829, '插入内容:我们真的需要自己都记不住的密码吗？', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601012, '更新频道:科技动态', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601240, '插入内容:孔子学院在美国校园引发关注', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601372, '插入内容:告别通天塔：语言天才是怎样炼成的 告别通天塔：语言天才是怎样炼成的', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601456, '插入内容:想象力的那些事儿 想象力的那些事儿', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601487, '更新频道:文化寻觅', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601614, '插入内容:iphone4S推迟发售引抗议，iphone5传言要瘦身——华盛顿邮报', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601778, '插入内容:美国新世相：房客轰走了，惨！搬家公司喊来了，赚！', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601896, '插入内容:未来的交通：交通为城市空间让位', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326601962, '更新内容:视角：沉湎于对未来的无尽猜想 视角：沉湎于对未来的无尽猜想 视角：沉湎于对未来的无尽猜想', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326603133, '更新单页:关于我们', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326603153, '更新单页:关于我们', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326603310, '更新设置', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604607, '登陆系统:admin', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604866, '更新设置', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604878, '更新菜单:Home', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604899, '更新菜单:ComTech', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604914, '更新菜单:Commercial News', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326604929, '更新菜单:Technical Trends', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605002, '更新菜单:Social-Culture', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605013, '更新菜单:Culture', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605027, '更新菜单:Society', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605048, '更新菜单:Life and Health', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605056, '更新菜单:Life', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605065, '更新菜单:Health', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605083, '更新菜单:Nature and PE', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605098, '更新菜单:Nature', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605114, '更新菜单:Sports', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605127, '更新菜单:Nature and Sports', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605138, '更新菜单:About US', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605161, '更新菜单:Guestbook', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605248, '更新频道:Commerce', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605267, '更新频道:Technique', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605279, '更新频道:Culture', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605290, '更新频道:Society', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605299, '更新频道:Life', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605309, '更新频道:Health', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605318, '更新频道:Nature', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605326, '更新频道:Sports', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605390, '更新内容:China’s railways:Less express', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605541, '更新内容:China’s railways:Less express', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605619, '更新内容:New Rules on Swaps Will Protect Big Traders - NYTimes.com', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605694, '更新内容:Germany and the euro: Unhappy new year | The Economist', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605752, '更新内容:Samsung Galaxy Note', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605807, '更新内容:How Can I Tell if My Phone''s Performance Measures Up?', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605851, '更新内容:Do You Really Need a Password You Can Barely Remember?', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326605936, '更新内容:Chinese funds on US campuses raise concerns – USATODAYcom', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606006, '更新内容:Foreign languages: The gift of tongues | The Economist', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606052, '更新内容:Martin Scorsese On Vision In Hollywood | Fast Company', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606129, '更新内容:IPhone 4S delay in China sparks protests, iPhone 5 rumored to have slimmer design - The Washington Post', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606191, '更新内容:Moving evicted tenants is ''lucrative'' business – USATODAYcom', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606254, '更新内容:：A Point of View: The endless obsession with what might be', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326606332, '更新投票:Which browser are you using？', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326610817, '更新设置', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326610847, 'UpdatesSet up', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326610981, '更新设置', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326611014, 'UpdatesSet up', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326612060, '更新单页:About', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326612109, '更新单页:About', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326612166, '更新单页:About', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326612235, '更新单页:About', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326612881, 'EmptyCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326613430, 'EmptyCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326613598, 'EmptyCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326614561, 'EmptyCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326614567, 'QuitSystem:admin', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326614717, 'QuitSystem', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 0),
(1326614723, 'Log inSystem:admin', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.8 (KHTML, like Gecko) Chrome/17.0.942.0 Safari/535.8', 1),
(1326632835, 'Log inSystem:admin', '127.0.0.1', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; baiduds; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; staticlogin:product=cboxf2010&act=login&info=ZmlsZW5hbWU9UG93ZXJXb3JkMjAxME94Zl9VbHRpbWF0ZS5leGUmbWFjPTI4RDQ4NzZGMzYyQjQyQzlBR', 1),
(1326632847, 'UpdatesSet up', '127.0.0.1', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; baiduds; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; staticlogin:product=cboxf2010&act=login&info=ZmlsZW5hbWU9UG93ZXJXb3JkMjAxME94Zl9VbHRpbWF0ZS5leGUmbWFjPTI4RDQ4NzZGMzYyQjQyQzlBR', 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_config`
--

CREATE TABLE IF NOT EXISTS `x_config` (
  `config_type` varchar(10) NOT NULL DEFAULT '',
  `config_value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_config`
--

INSERT INTO `x_config` (`config_type`, `config_value`) VALUES
('config', 'YTozNTp7czo5OiJzaXRlX25hbWUiO3M6MTU6IueOr+eQg+aWh+eroOaxhyI7czo4OiJzaXRlX2ljcCI7czoxNzoiSUNQ5aSHMDAwMDAwMDHlj7ciO3M6MTM6InNpdGVfa2V5d29yZHMiO3M6MTU6IueOr+eQg+aWh+eroOaxhyI7czoxNjoic2l0ZV9kZXNjcmlwdGlvbiI7czoxNToi546v55CD5paH56ug5rGHIjtzOjExOiJzaXRlX25vdGljZSI7czozOToi5L2g5aW977yB5qyi6L+O6K6/6Zeu546v55CD5paH56ug5rGH77yBIjtzOjEwOiJzaXRlX3N0YXRlIjtzOjM6InllcyI7czoxNToic2l0ZV9jbG9zZV90ZXh0IjtzOjI5OiJ1bmRlciBjb25zdHJ1Y3Rpb24h4oCm4oCmXl9eISI7czo3OiJzaXRlX2lwIjtzOjIyOiIxMC4xMC4xMC4qDQoxMjcuMC4wLjEwIjtzOjEzOiJzaXRlX2JhZHdvcmRzIjtzOjY4OiLkuK3lm7095aSp5pydDQpTQj3mlofmmI7nlKjor60NCjJCPeaWh+aYjueUqOivrQ0K5pONPeeIsQ0K6I2JPeWTiOWTiCI7czoxMzoic2l0ZV9sYW5ndWFnZSI7czo3OiJlbmdsaXNoIjtzOjEzOiJzaXRlX3RlbXBsYXRlIjtzOjc6ImRlZmF1bHQiO3M6MTE6Im9ubGluZV90aW1lIjtpOjMwO3M6MTM6InJld3JpdGVfc3RhdGUiO3M6Mjoibm8iO3M6MTQ6ImZlZWRiYWNrX3N0YXRlIjtzOjI6Im5vIjtzOjEzOiJmZWVkYmFja19zaXplIjtzOjE6IjUiO3M6MTM6ImNvbW1lbnRfc3RhdGUiO3M6Mjoibm8iO3M6MTI6Im1lbWJlcl9zdGF0ZSI7czozOiJ5ZXMiO3M6MjM6Im1lbWJlcl92YWxpZGF0aW9uX3N0YXRlIjtzOjI6Im5vIjtzOjE4OiJpbmRleF9jb21tZW50X3NpemUiO2k6MTA7czoyNjoiaW5kZXhfY29tbWVudF9jb250ZW50X3NpemUiO2k6NTtzOjE2OiJjb250ZW50X2hvdF9zaXplIjtpOjU7czoyMjoiY29udGVudF9ob3RfdGl0bGVfc2l6ZSI7aTo1O3M6MTc6ImNvbnRlbnRfYmVzdF9zaXplIjtpOjU7czoyMzoiY29udGVudF9iZXN0X3RpdGxlX3NpemUiO2k6NTtzOjEyOiJjb21tZW50X3NpemUiO2k6MTU7czoxMToic2VhcmNoX3NpemUiO2k6MTU7czoxMToic210cF9zZXJ2ZXIiO3M6MDoiIjtzOjk6InNtdHBfcG9ydCI7czoyOiIyNSI7czo5OiJzbXRwX3VzZXIiO3M6MDoiIjtzOjEzOiJzbXRwX3Bhc3N3b3JkIjtzOjA6IiI7czoxNjoiaW1hZ2VfdGh1bWJfb3BlbiI7czoyOiJubyI7czoxNzoiaW1hZ2VfdGh1bWJfd2lkdGgiO2k6MTAwO3M6MTg6ImltYWdlX3RodW1iX2hlaWdodCI7aToxMDA7czoxNToiaW1hZ2VfdGV4dF9vcGVuIjtzOjI6Im5vIjtzOjk6ImltYWdlX3BvcyI7aToxO30=');

-- --------------------------------------------------------

--
-- Table structure for table `x_content`
--

CREATE TABLE IF NOT EXISTS `x_content` (
  `content_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `content_title` varchar(255) NOT NULL,
  `content_url` varchar(255) NOT NULL DEFAULT '',
  `content_keywords` varchar(255) NOT NULL DEFAULT '',
  `content_text` text NOT NULL,
  `content_description` varchar(255) NOT NULL DEFAULT '',
  `content_password` varchar(255) NOT NULL,
  `content_thumb` varchar(255) NOT NULL,
  `content_support` smallint(5) unsigned NOT NULL DEFAULT '0',
  `content_against` smallint(5) unsigned NOT NULL DEFAULT '0',
  `content_click_count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content_comment_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `content_is_best` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_is_comment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_time` int(10) unsigned NOT NULL DEFAULT '0',
  `channel_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `category_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `member_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `x_content`
--

INSERT INTO `x_content` (`content_id`, `content_title`, `content_url`, `content_keywords`, `content_text`, `content_description`, `content_password`, `content_thumb`, `content_support`, `content_against`, `content_click_count`, `content_comment_count`, `content_is_best`, `content_is_comment`, `content_state`, `content_time`, `channel_id`, `category_id`, `member_id`) VALUES
(1, '中国铁路需要减缓速度', '', '', '这个国家需要的是更高效的网络，而不是更快的火车\n\n2012年1月7日|香港|印刷版\n\n\n中国对高铁的热爱再次升温。官员们不惧可怕的事故和巨大的成本超支，正计划进一步扩大国家的高速铁路网。广州和深圳之间开通了一项新服务，将旅行时间缩短近一半，至35分钟。列车时速可达380公里(236英里)，该服务最终将扩展到附近的香港。对于那些渴望更快速度的人来说，中国最大的火车制造商中国南车公司推出了一款超级列车(见上图)，据说它的灵感来自于中国古代的一把剑。它应该以每小时500公里的速度穿过空气。', '', '', '', 0, 0, 7, 0, 1, 1, 1, 1326599764, 1, 0, 0),
(2, '互惠信贷发布新规将保护大贸易商 - 来源：NYTimes.com', '', '', '根据美国联邦监管机构周三通过的一项计划，华尔街投资者将获得重要的新保护。该计划是在全球曼氏金融(MF Global)破产后出台的。\n\n去年MF Global申请破产时，这家经纪公司约有12亿美元的客户资金消失了。该公司的期货客户，包括农民和对冲基金，仍然损失了近三分之一的资金。\n\n但新规定不会阻止经纪公司重复MF Global滥用客户资金的错误，也不适用于像MF Global这样的任何期货行业客户。', '', '', '', 0, 0, 5, 0, 0, 1, 1, 1326599911, 1, 0, 0),
(7, '你真的需要一个难以记住的密码吗？', '', '', '2004年，比尔·盖茨宣布密码不会在这个世界上存在太久;现在，微软研究院的一篇论文称，有充分的理由说明它永远不会消失。图片来源:Eric E. Castro/Flickr\n\n\n想一个词。一个密码。至少8个字符，但不超过12个字符。不要重复任何字符超过两次。确保至少有一个字母和一个数字。事实上，它必须从一个数字开始。您不能使用过去使用过的用户名或密码。最后，您必须在密码中使用以下字符之一:~!@#$%^&*()-_+={}[]|;:/?.，<>。\n\n尽量让它令人难忘。你不应该把它写下来，但几个月后，当你回到这个网站时，你可能会再次需要它。\n\n困惑的感觉怎么样?安全专家告诉我们，我们应该让自己的密码难以猜测，但一些网站却残忍地强迫我们想出无法猜测(或记住)的密码。', '', '', '', 0, 0, 3, 0, 0, 1, 1, 1326600829, 2, 0, 0),
(8, '美国大学接受中国政府资助引发众人对学术自由的担忧', '', '', '90多个国家的300多所大学——包括美国的大约70所大学——设立了孔子学院，即由中国政府资助的中国语言文化教育和研究中心。中国政府对国际大学的资金注入使得语言教学、文化项目和与中国有关的会议和专题讨论会得以显著扩张，但这也引发了对学术自由和教学研究独立性的担忧。批评人士质疑，为什么大学会向被中国宣传部长李长春描述为“中国海外宣传机构的重要组成部分”的机构提供许可。', '', '', '', 0, 0, 1, 0, 0, 1, 1, 1326601240, 3, 0, 0),
(9, '语言天赋', '', '', '是什么让一些人学习一门又一门语言?\n\n博洛尼亚的MEZZOFANTI枢机主教是一位世俗的圣人。尽管他从未创造过被正式册封为圣徒所需的奇迹，但他的力量近乎超凡脱俗。据说Mezzofanti会说72种语言。或者50。或者完全掌握了30。没有人能确定真实的数字，但确实很多。游客们从欧洲各个角落蜂拥而至，来测试他的能力。他可以轻松地在语言之间切换。两名死刑犯即将被处决，但没有人知道他们的语言，听不到他们的供词。Mezzofanti一夜之间就学会了，第二天早上听到了他们的罪恶，把他们从地狱里救了出来。\n至少传说是这样的。在《不再有通天塔》一书中，迈克尔•埃拉德写了第一本严肃的关于精通大量语言的人的书——或者自称精通大量语言的人的书。作为一名接受过一些语言学训练的记者，Erard先生本身并不是一个精通多种语言的人(他会说一些西班牙语和中文)，但他在处理他的话题时既带着好奇，又带着一丝健康的怀疑。', '', '', '', 0, 0, 5, 0, 0, 1, 1, 1326601372, 3, 0, 0),
(10, '马丁·斯科塞斯谈好莱坞视觉效果|来源：Fast Company', '', '', '69岁的马丁·斯科塞斯(Martin Scorsese)再一次为赶在最后期限前完成任务而感到恐慌，在这个年纪，大多数好莱坞导演都在经历了一场空洞的喝彩、烤烤和怀旧的庆祝活动后离开了人世。他的新电影是《雨果》，一部3d儿童电影，派拉蒙影业将于感恩节周末发行。斯科塞斯以前从未执导过3d电影，上帝知道，也没有拍过任何类似儿童电影的东西。但这就是马蒂的生活，大家都这么叫他。这位导演已经实现了充实而富有创造力的生活:有足够的钱只做他真正感兴趣的事情，有足够的自由以令人满意的方式攻击这些项目，还有来自同行的足够的赞赏，以驯服——只是一点点，只是非常一点点——自我怀疑的神经质野兽。22部电影，5个广告，13部纪录片，一些音乐录影带，三个孩子，五个妻子，25个工作室;在破产和痛苦之后，在票房失败和多年不被赏识之后;马蒂·斯科塞斯(Marty Scorsese)赢得了一个奥斯卡奖和所有他本应赢得的奖项，他赢得了每个有创造力的人梦寐以求的权利:永远不会感到无聊的权利。所有这些对他来说意味着什么，对这个特别的人来说意味着什么，他赢得了在接下来的十年里继续为世界上的每一个小细节烦恼的权利，只要他愿意拍电影。', '', '', '', 1, 0, 9, 0, 0, 1, 1, 1326601456, 3, 0, 0),
(11, '苹果公司推迟IPhone 4S在中国的上市时间引起群众抗议，传言IPhone 5设计更薄——来源：华盛顿邮报', '', '', '苹果(Apple)最新款智能手机iPhone 4S在中国的发布在北京遇到了障碍，因为对聚集的人群感到担忧，导致旗舰店取消了发布会。正如伊丽莎白·弗洛克(Elizabeth Flock)报道的那样，许多人对这一声明并不满意:\n\n在美国，一款新的iPhone或其他苹果产品的发布总是伴随着某种程度的狂热。但据美联社报道，周五，愤怒的北京消费者和黄牛将事态发展到了另一个高度，他们对苹果中国旗舰店的员工大喊大叫，并向其投掷鸡蛋。\n苹果公司(Apple Inc.)周五推迟了iPhone 4S在中国大陆门店的销售，此前愤怒的顾客和黄牛团伙向苹果北京旗舰店扔鸡蛋。(1月13日)。\n\n在警方宣布由于担心人群规模过大而取消iPhone 4S在中国的发布后，顾客们做出了反应。许多顾客在商店外露营过夜。\n\n这并不是苹果在中国发生的第一起此类事件。去年5月，当中国收到第一批iPad 2时，北京的一家苹果店也发生了类似的混战。一名黄牛插队后，一场打斗导致四人受伤，一扇玻璃门被打碎。', '', '', '', 0, 0, 1, 0, 0, 1, 1, 1326601614, 4, 0, 0),
(12, '为被驱逐的租户提供搬迁服务是一项“有利可图”的业务 – 来源：USATODAYcom', '', '', '纽约(美联社)——全国各地的业主都承受着经济衰退带来的负担:他们要支付大笔的搬家和仓储费用来驱逐那些无法支付租金的租户。\n但是业主的损失对于清理房屋的公司来说是一个福音。纽约法律服务公司(Legal Services NYC)的律师大卫·罗宾逊(David Robinson)说，他们的生意突飞猛进，“从人们的痛苦中赚钱”，该公司帮助低收入的纽约人处理驱逐程序。\n住房专家表示，受影响最严重的是少数民族城市社区，那里被迫离开的租房者大约是普通人群的两倍。\n最近的研究显示，低收入的黑人女性，通常是单身母亲，最有可能因为付不起房租而被驱逐。', '', '', '', 0, 0, 2, 0, 0, 1, 1, 1326601778, 4, 0, 0),
(13, '对于“不断思考未来而不是活在当下”的看法', '', '', '约翰·格雷(John Gray)写道，如果我们能停止思考未来会带来什么，拥抱现在的样子，我们会过得更好。\n\n历史没有终结已经有一段时间了。二十多年前，当柏林墙倒塌时，许多人相信不会再有严重的冲突。\n\n美国作家弗朗西斯·福山(Francis Fukuyama)在1989年秋提出了历史终结的观点，他宣称未来的主要威胁将是无聊。一个不同于以往的新时代已经到来。\n\n当然没有。苏联解体后，就发生了帝国解体时所发生的那种冲突和动荡——例如高加索战争和俄罗斯经济崩溃。\n\n从任何现实的角度来看，认为一个事件——无论多么大——可以标志着人类冲突的结束的想法都是荒谬的。但是那些被这个想法诱惑的人并没有从现实的角度考虑问题。', '', '', '', 0, 0, 2, 0, 0, 1, 1, 1326601896, 4, 0, 0),
(3, '德国与欧元区：度过的一个不愉快的新年', '', '', '欧元区领导人会谈，但没有解决他们的危机\n\n2012年1月14日| 柏林|来自印刷版\n\n尼古拉斯和马里奥。安吉拉和尼古拉斯。马里奥和安吉拉。今年伊始，欧元区三大经济体的领导人就开始了一场速配。他们谈论的是单一货币，这一货币受到马里奥•蒙蒂领导的意大利、尼古拉•萨科齐领导的法国以及甚至更弱的地中海国家的经济失败的威胁，也受到安吉拉•默克尔领导的德国的教条主义的威胁。三位领导人承认，他们并没有避免所有的危险，但声称正在取得进展。默克尔在1月9日与萨科齐会晤后表示:“我们已经为中期政策奠定了基础，但还没有赢回信任。”\n\n所有人都在注意自己的举止，但紧张气氛很明显。蒙蒂是一名技术官僚(前欧盟委员)，于去年11月接替了民粹主义者西尔维奥•贝卢斯科尼，他在访问柏林时警告《世界报》，意大利人可能会转而反对他试图实施的痛苦改革，欧洲和德国将受到指责。萨科齐今年春天将面临艰难的连任竞选，他小心翼翼地隐藏了自己与默克尔的分歧，但对蒙蒂表示同情。这三个人是我们熟悉的默克尔合奏团的扩展版，他们将于1月20日在罗马聚会。', '', '', '', 0, 0, 7, 0, 0, 1, 1, 1326600016, 1, 0, 0),
(6, '如何判断手机性能是否达标?', '', '', '要检查浏览器的性能，请使用SunSpider或V8 JavaScript测试工具，它们可以在任何手机平台上工作。Speedtest.net移动应用程序是一个易于使用的工具，用于测试Android和iOS上的下载速度(在同一网络上，不同手机的下载速度可能不同)。\n\n电池寿命也可以表明是否该换新的了。要想显示手机电池随着时间的推移消耗有多快，可以试试另一款Android应用“电池图”(battery Graph)。不过，网络信号和软件的差异让比较不同手机的电池寿命变得困难。最好的方法是，如果你能拿起电话。你正在考虑升级到，就是在两台设备上播放同样的视频，并测量电池耗尽需要多长时间。', '', '', '', 0, 0, 1, 0, 0, 1, 1, 1326600767, 2, 0, 0),
(5, '三星手机 Galaxy Note即将发布', '', '', '亮点:5.3英寸的机身既可以是一款巨大的安卓手机，也可以是一款袖珍安卓平板电脑，但厚度只有iPhone那么大。除了尺寸之外，Galaxy Note的突出之处在于它试图复活命运多舛的触控笔。不过，这款笔远不止是一根简单的塑料棒:它的笔触非常细致，足以画出复杂的草图。\n\n正如《天桥骄子》(Project Runway)的冠军安雅·杨芝(Anya ayyoung - chee)告诉我的那样，“我喜欢它。如果我有这个，我真的可以用它来画我所有的素描。”\n\n值得注意的规格:1280×800分辨率屏幕;4G LTE连接;企业安全特性。\n\n供货时间:未来几周;定价尚未披露。\n东芝Excite X10', '', '', '', 0, 0, 8, 0, 0, 1, 1, 1326600510, 2, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_content_attachment`
--

CREATE TABLE IF NOT EXISTS `x_content_attachment` (
  `attachment_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_name` varchar(30) NOT NULL,
  `content_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`attachment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_content_category`
--

CREATE TABLE IF NOT EXISTS `x_content_category` (
  `category_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL DEFAULT '',
  `category_deep` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `category_sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `category_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `parent_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_id` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_content_channel`
--

CREATE TABLE IF NOT EXISTS `x_content_channel` (
  `channel_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(50) NOT NULL,
  `channel_description` varchar(255) NOT NULL,
  `channel_banner` varchar(255) NOT NULL DEFAULT '',
  `channel_index` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `channel_index_truncate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_index_size` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_index_style` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_list_truncate` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_list_size` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_list_style` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `channel_content_style` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `channel_content_count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `channel_sort` tinyint(3) NOT NULL DEFAULT '0',
  `channel_read_permissions` tinyint(3) NOT NULL DEFAULT '0',
  `channel_write_permissions` tinyint(3) NOT NULL DEFAULT '0',
  `channel_comment_permissions` tinyint(3) NOT NULL DEFAULT '0',
  `channel_upload_ext` varchar(255) NOT NULL DEFAULT '',
  `channel_cache` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `channel_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `x_content_channel`
--

INSERT INTO `x_content_channel` (`channel_id`, `channel_name`, `channel_description`, `channel_banner`, `channel_index`, `channel_index_truncate`, `channel_index_size`, `channel_index_style`, `channel_list_truncate`, `channel_list_size`, `channel_list_style`, `channel_content_style`, `channel_content_count`, `channel_sort`, `channel_read_permissions`, `channel_write_permissions`, `channel_comment_permissions`, `channel_upload_ext`, `channel_cache`, `channel_state`) VALUES
(1, '商业', '', '', 1, 20, 10, 1, 10, 10, 1, 1, 0, 0, -1, -2, -1, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(2, '科技', '', '', 1, 10, 6, 1, 10, 12, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(3, '文化', '', '', 1, 12, 3, 1, 50, 10, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(4, '社会', '', '', 1, 15, 10, 1, 60, 10, 4, 4, 0, 0, -1, -1, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(5, '生活', '', '', 0, 10, 10, 1, 10, 10, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(6, '健康', '', '', 0, 10, 10, 1, 10, 10, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(7, '自然', '', '', 0, 10, 10, 1, 10, 10, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1),
(8, '体育', '', '', 0, 10, 10, 1, 10, 10, 1, 1, 0, 0, -1, -2, 0, 'jpg,png,gif,bmp,zip,rar,tar,7z,torrent,mp3,wma,swf,doc,docx,xls,xlsx,ppt,pptx,mdb,mdbx', 1, 1);  
-- --------------------------------------------------------

--
-- Table structure for table `x_content_comment`
--

CREATE TABLE IF NOT EXISTS `x_content_comment` (
  `comment_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `comment_content` text NOT NULL,
  `comment_reply` text NOT NULL,
  `comment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_ip` varchar(50) NOT NULL DEFAULT '',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `parent_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `member_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_content_link`
--

CREATE TABLE IF NOT EXISTS `x_content_link` (
  `link_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL,
  `content_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_feedback`
--

CREATE TABLE IF NOT EXISTS `x_feedback` (
  `feedback_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `feedback_name` varchar(50) NOT NULL DEFAULT '',
  `feedback_content` text NOT NULL,
  `feedback_reply` text NOT NULL,
  `feedback_time` int(10) unsigned NOT NULL DEFAULT '0',
  `feedback_reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `feedback_ip` varchar(20) NOT NULL DEFAULT '',
  `feedback_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`feedback_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_link`
--

CREATE TABLE IF NOT EXISTS `x_link` (
  `link_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `link_name` varchar(50) NOT NULL,
  `link_logo` varchar(100) NOT NULL DEFAULT '',
  `link_text` varchar(255) NOT NULL,
  `link_url` varchar(255) NOT NULL,
  `link_sort` int(4) unsigned NOT NULL DEFAULT '0',
  `link_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_member`
--

CREATE TABLE IF NOT EXISTS `x_member` (
  `member_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `member_nickname` varchar(50) NOT NULL DEFAULT '',
  `member_mail` varchar(255) NOT NULL,
  `member_password` varchar(255) NOT NULL,
  `member_safecode` varchar(255) NOT NULL,
  `member_name` varchar(50) NOT NULL DEFAULT '',
  `member_sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `member_birthday` int(10) unsigned NOT NULL DEFAULT '0',
  `member_phone` varchar(50) NOT NULL DEFAULT '',
  `member_photo` varchar(50) NOT NULL DEFAULT '',
  `member_from` varchar(255) NOT NULL DEFAULT '',
  `member_other` varchar(255) NOT NULL DEFAULT '',
  `member_join_time` int(10) NOT NULL DEFAULT '0',
  `member_last_time` int(10) NOT NULL DEFAULT '0',
  `member_last_ip` varchar(50) NOT NULL,
  `member_validation` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `member_validation_key` varchar(32) NOT NULL,
  `member_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `group_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_member_group`
--

CREATE TABLE IF NOT EXISTS `x_member_group` (
  `group_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `x_menu`
--

CREATE TABLE IF NOT EXISTS `x_menu` (
  `menu_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(50) NOT NULL,
  `menu_link` varchar(255) NOT NULL,
  `menu_target` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `menu_mode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `menu_sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `menu_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `parent_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `x_menu`
--

INSERT INTO `x_menu` (`menu_id`, `menu_name`, `menu_link`, `menu_target`, `menu_mode`, `menu_sort`, `menu_state`, `parent_id`) VALUES
(1, '主页', './', 0, 0, 1, 1, 0),
(2, '通信技术', 'channel.php?id=1', 0, 0, 1, 1, 0),
(3, '社会文化', 'channel.php?id=2', 0, 0, 1, 1, 0),
(4, '生活与健康', 'channel.php?id=3', 0, 0, 1, 1, 0),
(5, '自然与体育', 'channel.php?id=4', 0, 0, 1, 1, 0),
(6, '关于我们', 'page.php?id=1', 0, 0, 1, 1, 0),
(8, '留言板', 'feedback.php', 0, 0, 1, 1, 0),
(9, '经济新闻', 'channel.php?id=1', 0, 0, 1, 1, 2),
(10, '科技趋势', 'channel.php?id=2', 0, 0, 1, 1, 2),
(12, '文化', 'channel.php?id=3', 0, 0, 1, 1, 3),
(13, '社会', 'channel.php?id=4', 0, 0, 1, 1, 3),
(14, '生活', 'channel.php?id=5', 0, 0, 1, 1, 4),
(15, '健康', 'channel.php?id=6', 0, 0, 1, 1, 4),
(16, '自然', 'channel.php?id=7', 0, 0, 1, 1, 5),
(17, '体育', 'channel.php?id=8', 0, 0, 1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `x_online`
--

CREATE TABLE IF NOT EXISTS `x_online` (
  `online_time` int(10) unsigned NOT NULL DEFAULT '0',
  `online_ip` varchar(20) NOT NULL,
  `online_url` varchar(255) NOT NULL,
  `online_agent` varchar(255) NOT NULL,
  KEY `onlinetime` (`online_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `x_online`
--

INSERT INTO `x_online` (`online_time`, `online_ip`, `online_url`, `online_agent`) VALUES
(1326636792, '127.0.0.1', 'channel.php?id=1', 'Windows 7/Chrome');

-- --------------------------------------------------------

--
-- Table structure for table `x_page`
--

CREATE TABLE IF NOT EXISTS `x_page` (
  `page_id` int(3) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL DEFAULT '',
  `page_content` text NOT NULL,
  `page_permissions` int(3) NOT NULL DEFAULT '0',
  `page_sort` int(3) unsigned NOT NULL DEFAULT '0',
  `page_state` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `x_page`
--

INSERT INTO `x_page` (`page_id`, `page_title`, `page_content`, `page_permissions`, `page_sort`, `page_state`) VALUES
(1, '关于我们', '网络世界选择了当前的运营模式，作为开放社区和UGC翻译家站的一方来指导翻译威客平台的结合。在全球信息网络中有精选，用户可以自愿提交原创、翻译或阅读的文章，站边编辑是不断发现优质的原创来源，具有一定实力的译者和热门阅读。站方获得原创版权，译者在短时间内组织社区合作高效翻译，并将翻译的内容转售给需求方，收益分成实现了版权方、译者、站方的双赢局面。经过近一年的尝试和探索，这一模式取得了不小的效果，受到了客户和用户的欢迎，主要体现在:\n\n通过建立高质量的翻译和翻译社区，吸引了全球信息网络中挑选了一批国内高端和热心的翻译群体。已成为国内最大的翻译社区，最终形成版权社会的引进翻译和创作平台。当前的期刊、教材、图书等主题的翻译都是文字翻译的体现形式。\n通过互联网改变了传统的部分翻译出版业的价值和版权转化为国内发行的操作流程。在传统模式下，翻译从原著的引进、版权、印刷、发行、阅读等环节冗长、耗时，而且译者在其中的收入很少。网络世界选择了网络的形式，实现了各方面的高效率、高产量的实时无缝对接，为译者提供了空间上的好处。\n翻译是很多社区大学生做的翻译，社区活动为帮助他们提升自己的生产技能和就业质量提供了必要的培训。许多翻译用户在翻译活动中建立了个人声誉，找到了工作机会。\n在实现商业价值的同时，全球信息网络纷纷选择牢记自己的社会责任，从最初的“翻译救国”理念，具体到现在的跨越语言之间的知识壁垒，促进外语学习者的学习热情和自身价值的实现。此外，从翻译《救灾手册》开始，积极参与文字翻译公益项目，并作为与友会、爱心翻译等项目团队开展了长期合作。该慈善机构也得到了国际媒体的广泛认可和赞扬。', -1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_vote`
--

CREATE TABLE IF NOT EXISTS `x_vote` (
  `vote_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `vote_title` varchar(255) NOT NULL,
  `vote_start` int(10) unsigned NOT NULL DEFAULT '0',
  `vote_end` int(10) unsigned NOT NULL DEFAULT '0',
  `vote_mode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vote_place` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vote_state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `x_vote`
--

INSERT INTO `x_vote` (`vote_id`, `vote_title`, `vote_start`, `vote_end`, `vote_mode`, `vote_place`, `vote_state`) VALUES
(1, '您在使用什么浏览器？', 1293724800, 1327075200, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_vote_item`
--

CREATE TABLE IF NOT EXISTS `x_vote_item` (
  `item_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `vote_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `x_vote_item`
--

INSERT INTO `x_vote_item` (`item_id`, `item_title`, `item_count`, `vote_id`) VALUES
(1, 'IE', 0, 1),
(2, 'Google Chrome', 0, 1),
(3, 'Firefox', 0, 1),
(4, 'Opera', 0, 1),
(5, 'Safari', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_vote_log`
--

CREATE TABLE IF NOT EXISTS `x_vote_log` (
  `log_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `log_ip` varchar(50) NOT NULL DEFAULT '',
  `log_agent` varchar(255) NOT NULL DEFAULT '',
  `log_time` int(10) unsigned NOT NULL DEFAULT '0',
  `vote_id` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
