<?php
$db_host='localhost';
$db_user='root';
$db_password='root';
$db_name='en';
$db_prefix='x_';
?>
