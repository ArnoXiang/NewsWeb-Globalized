<?php
require_once'includes/global.php';
require_once'includes/front.php';
header('Content-Type:text/xml');
$xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\r\n";
$xml.="<url>\r\n";
$xml.="\t<loc>".get_position()."</loc>\r\n";
$xml.="\t<changefreq>daily</changefreq>\r\n";
$xml.="\t<priority>0.8</priority>\r\n";
$xml.="</url>\r\n";
$res=$db->getall("SELECT * FROM ".$GLOBALS['db_prefix']."content WHERE content_state=1 AND content_password='' ORDER BY `content_time` ASC");
	if($res){
		foreach($res as $row){
			$xml.="<url>\r\n";
			$xml.="\t<loc>".get_position().create_uri('content',array('id'=>$row['content_id']))."</loc>\r\n";
			$xml.="\t<lastmod>".date('c',$row['content_time'])."</lastmod>\r\n";
			$xml.="\t<changefreq>monthly</changefreq>\r\n";
			$xml.="\t<priority>0.5</priority>\r\n";
			$xml.="</url>\r\n";
		}
	}
$xml.="</urlset>\r\n";
echo $xml;
?>