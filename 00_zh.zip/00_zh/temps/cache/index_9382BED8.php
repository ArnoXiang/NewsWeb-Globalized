<?php exit;?>a:3:{s:8:"template";a:8:{i:0;s:79:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/channel_index_1.html";i:1;s:69:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/index.html";i:2;s:70:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/header.html";i:3;s:76:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/part_content.html";i:4;s:76:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/part_comment.html";i:5;s:73:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/part_vote.html";i:6;s:73:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/part_link.html";i:7;s:70:"D:/BACKPACK/phpstudy/phpstudy_pro/WWW/Zh/templates/default/footer.html";}s:7:"expires";i:1690276597;s:8:"maketime";i:1690272997;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>环球文章汇</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="keywords" content="环球文章汇" />
<meta name="description" content="环球文章汇" />
<link rel="stylesheet" href="templates/default/style.css" />
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<script type="text/javascript" src="scripts/function.js"></script>
<script type="text/javascript">
function Search(){
var keyword=$("#search_keyword").val();
	if($.trim(keyword)==''||$.trim(keyword)=='请输入关键字'){
		alert('关键字不能为空！');
		$("#search_keyword").focus();
		return;
	}
	keyword=keyword.replace(/\'/gi,"");
	keyword=keyword.replace(/\"/gi,"");
	keyword=keyword.replace(/\?/gi,"");
	keyword=keyword.replace(/\%/gi,"");
	keyword=keyword.replace(/\./gi,"");
	keyword=keyword.replace(/\*/gi,"");
	window.location.href="search.php?keyword="+encodeURI(keyword);
}
</script>
<div id="header">
	<div id="search"><table><tr><td><input type="text" id="search_keyword"  class="input" value="请输入关键字" onfocus="if (this.value == '请输入关键字') {this.value = '';}" onblur="if (this.value == '') {this.value = '请输入关键字';}"/></td><td><input type="button" class="button" id="search_submit" onclick="Search()" value="搜索" /></td></tr></table></div>
	<a href="./"><img src="templates/default/images/logo.gif" /></a>
</div>
<div id="nav">
	<div id="top_menu">
		<ul class="topnav">
						<li><a href="./"  class="active">主页</a></li>
			<li class="nav_split"></li>
						<li><a href="channel.php?id=1"  >商业</a><ul class="subnav"><li><a href="channel.php?id=1">经济新闻</a></li><li><a href="channel.php?id=2">科技趋势</a></li></ul></li>
			<li class="nav_split"></li>
						<li><a href="channel.php?id=2"  >社会文化</a><ul class="subnav"><li><a href="channel.php?id=3">文化</a></li><li><a href="channel.php?id=4">社会</a></li></ul></li>
			<li class="nav_split"></li>
						<li><a href="channel.php?id=3"  >生活与健康</a><ul class="subnav"><li><a href="channel.php?id=5">生活</a></li><li><a href="channel.php?id=6">健康</a></li></ul></li>
			<li class="nav_split"></li>
						<li><a href="channel.php?id=4"  >自然与体育</a><ul class="subnav"><li><a href="channel.php?id=7">自然</a></li><li><a href="channel.php?id=8">体育</a></li></ul></li>
			<li class="nav_split"></li>
						<li><a href="page.php?id=1"  >网站简介</a></li>
			<li class="nav_split"></li>
						<li><a href="feedback.php"  >留言板</a></li>
			<li class="nav_split"></li>
					</ul>
		<div class="clearleft blank"></div>
	</div>
	<div id="here">你好！欢迎访问环球文章汇！</div>
	
			<div id="inner">
		<span id="member_info"></span>
<script type="text/javascript">
function login(){
	$.ajax({
		type:"GET",
		url:"member.php?action=login&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('登录',360,170,e);
			
			$('#join_member').click(function(){
				$('#box_mask').remove();
				$('#box_body').empty();
				$('#box_body').remove();
				register();
			});
			$('#member_forget').click(function(){
				$('#box_mask').remove();
				$('#box_body').empty();
				$('#box_body').remove();
				forget();
			});
			var logins=function(){
				var member_mail=$('#member_mail').val();
				var member_password=$('#member_password').val();
				if ($.trim(member_mail)==''){
					alert('电子邮箱不能为空！');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('电子邮箱无效！');
					return false;
				}
				if ($.trim(member_password)==''){
					alert('密码不能为空！');
					return false;
				}
				if (member_password.length<6&&member_password.length>20){
					alert('密码由6-20个字符组成，建议使用英文字母与数字或符号组合作为密码。');
					return false;
				}
				$.ajax({
					type:"GET",
					url:"member.php?action=login_ok&member_mail="+encodeURI(member_mail)+"&member_password="+encodeURI(member_password)+"&r="+Math.random(), 
					dataType:"text",
					async:false,
					success:function(e){
						if(e=='error:mail_is_empty'){
							alert('电子邮箱不能为空！');
							return false;
						}else if(e=='error:mail_is_error'){
							alert('电子邮箱无效！');
							return false;
						}else if(e=='error:password_is_empty'){
							alert('密码不能为空！');
							return false;
						}else if(e=='error:account_is_not_activate'){
							alert('您的账户未激活，请激活您的邮箱！');
							return false;
						}else if(e=='error:account_is_lock'){
							alert('您的帐号已被锁定，请联系管理员解锁！');
							return false;
						}else if(e=='error:login_failed'){
							alert('登录失败！');
							return false;
						}
						location.reload();
					}
				});
			};
			/*回车登陆管理*/
			$('#member_password,#member_mail').keydown(function(event){
				var event = event||window.event;
				var keycode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;
				if(keycode==13){
					logins();
				}
			});
			$("#login_submit").click(function(){
				logins();
			});
		}//end request form success
	});//end request form
}
function forget(){
	$.ajax({
		type:"GET",
		url:"member.php?action=forget&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('找回密码',360,140,e);
			var forget_submit=function(){
				var member_mail=$('#member_mail').val();
				var member_safecode=$('#member_safecode').val();
				if ($.trim(member_mail)==''){
					alert('电子邮箱不能为空！');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('电子邮箱无效！');
					return false;
				}
				if ($.trim(member_safecode)==''){
					alert('安全码不能为空！');
					return false;
				}
				$.ajax({
					type:"GET",
					url:"member.php?action=forget_ok&member_mail="+encodeURI(member_mail)+"&member_safecode="+encodeURI(member_safecode)+"&r="+Math.random(), 
					dataType:"text",
					async:false,
					success:function(e){
						alert(e);
						location.reload();
					}
				});
			};
	
			/*回车登陆管理*/
			$('#member_mail,#member_safecode').keydown(function(event){
				var event = event||window.event;
				var keycode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;
				if(keycode==13){
					forget_submit();
				}
			});
			$("#forget_submit_button").click(function(){
				forget_submit();
			});
		}//end request form success
	});//end request form
}
function register(){
	$.ajax({
		type:"GET",
		url:"member.php?action=register&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('注册',380,370,e);
			$("#member_mail").blur(function(){
				$.ajax({
					type:"GET",
					url:"member.php?action=check_member_mail&member_mail="+encodeURI(this.value)+"&r="+Math.random(), dataType:"text",async:false,success:function (e){	
					if (e==1) {
						$("#errMsg_member_mail").html("<img src='images/no.gif' align='absmiddle'/>");
					}else{
						$("#errMsg_member_mail").html("<img src='images/yes.gif' align='absmiddle'/>");
					}
				}});
			});
			$("#member_nickname").blur(function(){
				$.ajax({
					type:"GET",
					url:"member.php?action=check_member_nickname&member_nickname="+encodeURI(this.value)+"&r="+Math.random(), dataType:"text",async:false,success:function (e){
					if (e==1) {
						$("#errMsg_member_nickname").html("<img src='images/no.gif' align='absmiddle'/>");
					}else{
						$("#errMsg_member_nickname").html("<img src='images/yes.gif' align='absmiddle'/>");
					}
				}}); 
			});
			$("#member_password").blur(function(){
				var Mcolor = "#FFF",Lcolor = "#FFF",Hcolor = "#FFF";
				var m=0,Modes = 0,pwd=this.value;
				for (i=0; i<pwd.length; i++){
					var charType = 0;
					var t = pwd.charCodeAt(i);
					if (t>=48 && t <=57){
					  charType = 1;
					}else if (t>=65 && t <=90){
					  charType = 2;
					}else if (t>=97 && t <=122){
					  charType = 4;
					}else{
					  charType = 4;
					 }
					Modes |= charType;
				}
				for (i=0;i<4;i++){
					if(Modes & 1)m++;
					Modes>>>=1;
				}
				if (pwd.length<=4){
					m = 1;
				}
				switch(m){
				case 1 :
				  Lcolor = "2px solid red";
				  Mcolor = Hcolor = "2px solid #DADADA";
				break;
				case 2 :
				  Mcolor = "2px solid #f90";
				  Lcolor = Hcolor = "2px solid #DADADA";
				break;
				case 3 :
				  Hcolor = "2px solid #3c0";
				  Lcolor = Mcolor = "2px solid #DADADA";
				break;
				case 4 :
				  Hcolor = "2px solid #3c0";
				  Lcolor = Mcolor = "2px solid #DADADA";
				break;
				default :
				  Hcolor = Mcolor = Lcolor = "";
				break;
				}
				if (document.getElementById("pwd_lower")){
					document.getElementById("pwd_lower").style.borderBottom  = Lcolor;
					document.getElementById("pwd_middle").style.borderBottom = Mcolor;
					document.getElementById("pwd_high").style.borderBottom   = Hcolor;
				}
			});
			$("#register_submit").click(function(){
				var member_mail=$('#member_mail').val();
				var member_password=$('#member_password').val();
				var member_password_confirm=$('#member_password_confirm').val();
				var member_safecode=$('#member_safecode').val();
				var member_nickname=$('#member_nickname').val();
				if ($.trim(member_mail)==''){
					alert('电子邮箱不能为空！');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('电子邮箱无效！');
					return false;
				}
				if ($.trim(member_password)==''){
					alert('密码不能为空！');
					return false;
				}
				if (member_password.length<6&&member_password.length>20){
					alert('密码由6-20个字符组成，建议使用英文字母与数字或符号组合作为密码。');
					return false;
				}
				if ($.trim(member_password)!=$.trim(member_password_confirm)){
					alert('密码不一致！');
					return false;
				}
				if ($.trim(member_nickname)==''){
					alert('昵称不能为空！');
					return false;
				}
				if (member_password.length<2&&member_password.length>10){
					alert('昵称长度不能小于2或大于10！');
					return false;
				}
				if ($.trim(member_safecode)==''){
					alert('安全码不能为空！');
					return false;
				}
				if (member_safecode.length<2&&member_safecode.length>10){
					alert('安全码长度不能小于2或大于10！');
					return false;
				}
				$.ajax({type:"GET", url:"member.php?action=register_ok&member_mail="+encodeURI(member_mail)+"&member_password="+encodeURI(member_password)+"&member_password_confirm="+encodeURI(member_password_confirm)+"&member_nickname="+encodeURI(member_nickname)+"&member_safecode="+encodeURI(member_safecode)+"&r="+Math.random(), dataType:"text",async:false,success:function(e){
					if(e=='error:mail_is_empty'){
						alert('电子邮箱不能为空！');
						return false;
					}else if(e=='error:mail_is_error'){
						alert('电子邮箱无效！');
						return false;
					}else if(e=='error:mail_is_occupy'){
						alert('电子邮箱已被注册！');
						return false;
					}else if(e=='error:password_is_empty'){
						alert('密码不能为空！');
						return false;
					}else if(e=='error:password_is_error'){
						alert('密码不一致！');
						return false;
					}else if(e=='error:safecode_is_empty'){
						alert('安全码不能为空！');
						return false;
					}else if(e=='error:nickname_is_empty'){
						alert('昵称不能为空！');
						return false;
					}else if(e=='error:nickname_is_occupy'){
						alert('昵称已被占用！');
						return false;
					}
					location.reload();
					get_member_info();
				}});
			});
		}//end request form success
	});//end request form
}
function get_member_info(){
	$.ajax({
	type:"GET",
	url:"member.php?action=member_info&r="+Math.random(),
	dataType:"text",
	async:false,
	success:function(e){
		$('#member_info').html(e);
		$('#logout').click(function(){
			$.ajax({type:"GET", url:"member.php?action=logout&r="+Math.random(), dataType:"text",async:false,success:function (){	
				get_member_info();
			}});
		});
	}});	
}
get_member_info();
</script>
</div>
		</div>
<div class="blank"></div><div id="center">
	<div id="main">
		<div class="panel">
									<div style="margin:2px;width:340px;overflow:hidden;float:left">
				<div class="panel_caption">
					<a href="channel.php?id=1"><img src="templates/default/images/more.gif" alt="" align="absmiddle"/></a>
					商业				</div>
				<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=3"  title="德国与欧元区：度过的一个不愉快的新年" >德国与欧元区：度过的一个不愉快的新年</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=2"  title="互惠信贷发布新规将保护大贸易商 - 来源..." >互惠信贷发布新规将保护大贸易商 - 来源...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=1"  title="中国铁路需要减缓速度" >中国铁路需要减缓速度</a>
</p>
				</div>
							<div style="margin:2px;width:340px;overflow:hidden;float:left">
				<div class="panel_caption">
					<a href="channel.php?id=2"><img src="templates/default/images/more.gif" alt="" align="absmiddle"/></a>
					科技				</div>
				<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=7"  title="你真的需要一个难以记..." >你真的需要一个难以记...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=6"  title="如何判断手机性能是否..." >如何判断手机性能是否...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=5"  title="三星手机 Galax..." >三星手机 Galax...</a>
</p>
				</div>
							<div style="margin:2px;width:340px;overflow:hidden;float:left">
				<div class="panel_caption">
					<a href="channel.php?id=3"><img src="templates/default/images/more.gif" alt="" align="absmiddle"/></a>
					文化				</div>
				<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=10"  title="马丁·斯科塞斯谈好莱坞视..." >马丁·斯科塞斯谈好莱坞视...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=9"  title="语言天赋" >语言天赋</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=8"  title="美国大学接受中国政府资助..." >美国大学接受中国政府资助...</a>
</p>
				</div>
							<div style="margin:2px;width:340px;overflow:hidden;float:left">
				<div class="panel_caption">
					<a href="channel.php?id=4"><img src="templates/default/images/more.gif" alt="" align="absmiddle"/></a>
					社会				</div>
				<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=13"  title="对于“不断思考未来而不是活在当..." >对于“不断思考未来而不是活在当...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=12"  title="为被驱逐的租户提供搬迁服务是一..." >为被驱逐的租户提供搬迁服务是一...</a>
</p>
<p class="channel_index_1">
<span>2012-01-15</span>
<a href="content.php?id=11"  title="苹果公司推迟IPhone 4S..." >苹果公司推迟IPhone 4S...</a>
</p>
				</div>
							</div>
		<div><img src="templates/default/images/home_EN.jpg"></div>
	</div>
	<div id="in"></div>
	<div id="side">
		<div class="box">
	<div class="tab_tag">
		<div id="tab_tag_1" class="current" onclick="tab('tab',1,2)">大社区</div>
		<div id="tab_tag_2" onclick="tab('tab',2,2)">热门精选</div>
		<P class="clearleft"></P>
	</div>
	<div id="tab_body_1">
			<div class="side_list">
					<a href="content.php?id=10">马丁·斯科...</a>
					<a href="content.php?id=5">三星手机 ...</a>
					<a href="content.php?id=1">中国铁路需...</a>
					<a href="content.php?id=3">德国与欧元...</a>
					<a href="content.php?id=2">互惠信贷发...</a>
				</div>
		</div>
	<div id="tab_body_2" style="display:none">
			<div class="side_list">
					<a href="content.php?id=1">中国铁路需...</a>
				</div>
		</div>
</div>
<div class="blank"></div>		<div class="box">
<div class="box_title">最新评论</div>
</div>
<div class="blank"></div>
			</div>
	<div class="clear"></div>
	 <div class="blank"></div>
	
</div>
 <div id="footer">
	<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
	<td align="left">
	
	&nbsp;&copy;&nbsp;2005-2011环球文章汇<br />
	基于WEEDCMS V5.5管理系统
	
	</td><td align="right" valign="top">
			<br /><a href="http://www.miibeian.gov.cn/" target="_blank">ICP备00000001号</a>
		</td>
	</tr>
	</table>
</div></body>
</html>