<dl class='leftmenu'>
<dt><?php echo $this->_var['language']['menu_config']; ?></dt>
<dd><a href='?action=config&do=config' <?php if ($_REQUEST['do'] == 'config'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_config_1']; ?></a></dd>
<dd><a href='?action=config&do=menu_list' <?php if ($_REQUEST['do'] == 'menu_list' || $_REQUEST['do'] == 'menu_add' || $_REQUEST['do'] == 'menu_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_config_2']; ?></a></dd>
<dd><a href='?action=config&do=admin_list'  <?php if ($_REQUEST['do'] == 'admin_list' || $_REQUEST['do'] == 'admin_add' || $_REQUEST['do'] == 'admin_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_config_3']; ?></a></dd>
<dt><?php echo $this->_var['language']['menu_content']; ?></dt>
<dd><a href='?action=content&do=channel_list' <?php if ($_REQUEST['do'] == 'channel_list' || $_REQUEST['do'] == 'channel_add' || $_REQUEST['do'] == 'channel_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_content_1']; ?></a></dd>
<dd><a href='?action=content&do=page_list' <?php if ($_REQUEST['do'] == 'page_list' || $_REQUEST['do'] == 'page_add' || $_REQUEST['do'] == 'page_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_content_2']; ?></a></dd>
<dd><a href='?action=content&do=comment_list' <?php if ($_REQUEST['action'] == 'content'): ?><?php if ($_REQUEST['do'] == 'comment_list' || $_REQUEST['do'] == 'comment_edit'): ?>class="current"<?php endif; ?><?php endif; ?>><?php echo $this->_var['language']['menu_content_3']; ?></a></dd>

<dt><?php echo $this->_var['language']['menu_member']; ?></dt>
<dd><a href='?action=member&do=member_list'<?php if ($_REQUEST['do'] == 'member_list' || $_REQUEST['do'] == 'member_add' || $_REQUEST['do'] == 'member_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_member_1']; ?></a></dd>
<dd><a href='?action=member&do=group_list'<?php if ($_REQUEST['do'] == 'group_list' || $_REQUEST['do'] == 'group_add' || $_REQUEST['do'] == 'group_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_member_2']; ?></a></dd>
<dt><?php echo $this->_var['language']['menu_other']; ?></dt>
<dd><a href='?action=other&do=ad_list'<?php if ($_REQUEST['do'] == 'ad_list' || $_REQUEST['do'] == 'ad_add' || $_REQUEST['do'] == 'ad_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_other_1']; ?></a></dd>
<dd><a href='?action=other&do=vote_list'<?php if ($_REQUEST['do'] == 'vote_list' || $_REQUEST['do'] == 'vote_add' || $_REQUEST['do'] == 'vote_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_other_2']; ?></a></dd>
<dd><a href='?action=other&do=link_list' <?php if ($_REQUEST['do'] == 'link_list' || $_REQUEST['do'] == 'link_add' || $_REQUEST['do'] == 'link_edit'): ?>class="current"<?php endif; ?>><?php echo $this->_var['language']['menu_other_3']; ?></a></dd>
</dl>