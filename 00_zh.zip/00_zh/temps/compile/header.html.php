<script type="text/javascript" src="scripts/function.js"></script>
<script type="text/javascript">
function Search(){
var keyword=$("#search_keyword").val();
	if($.trim(keyword)==''||$.trim(keyword)=='<?php echo $this->_var['language']['please_put_keyword']; ?>'){
		alert('<?php echo $this->_var['language']['keyword_is_empty']; ?>');
		$("#search_keyword").focus();
		return;
	}
	keyword=keyword.replace(/\'/gi,"");
	keyword=keyword.replace(/\"/gi,"");
	keyword=keyword.replace(/\?/gi,"");
	keyword=keyword.replace(/\%/gi,"");
	keyword=keyword.replace(/\./gi,"");
	keyword=keyword.replace(/\*/gi,"");
	window.location.href="search.php?keyword="+encodeURI(keyword);
}
</script>
<div id="header">
	<div id="search"><table><tr><td><input type="text" id="search_keyword"  class="input" value="<?php echo $this->_var['language']['please_put_keyword']; ?>" onfocus="if (this.value == '<?php echo $this->_var['language']['please_put_keyword']; ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php echo $this->_var['language']['please_put_keyword']; ?>';}"/></td><td><input type="button" class="button" id="search_submit" onclick="Search()" value="<?php echo $this->_var['language']['search']; ?>" /></td></tr></table></div>
	<a href="./"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/logo.gif" /></a>
</div>

<?php if ($this->_var['top_menu']): ?>
<div id="nav">
	<div id="top_menu">
		<ul class="topnav">
			<?php $_from = $this->_var['top_menu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'menu');if (count($_from)):
    foreach ($_from AS $this->_var['menu']):
?>
			<li><a href="<?php echo $this->_var['menu']['link']; ?>" <?php if ($this->_var['menu']['target'] == 1): ?>target="_blank"<?php endif; ?> <?php if ($this->_var['menu']['active']): ?>class="active"<?php endif; ?>><?php echo $this->_var['menu']['name']; ?></a><?php if ($this->_var['menu']['children']): ?><ul class="subnav"><?php $_from = $this->_var['menu']['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');if (count($_from)):
    foreach ($_from AS $this->_var['child']):
?><li><a href="<?php echo $this->_var['child']['link']; ?>"><?php echo $this->_var['child']['name']; ?></a></li><?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?></ul><?php endif; ?></li>
			<li class="nav_split"></li>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		</ul>
		<div class="clearleft blank"></div>
	</div>
	<div id="here"><?php echo $this->_var['here']; ?></div>
	
		<?php if ($this->_var['config']['member_state'] == 'yes'): ?>
	<div id="inner">
		<span id="member_info"></span>
<script type="text/javascript">
function login(){
	$.ajax({
		type:"GET",
		url:"member.php?action=login&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('<?php echo $this->_var['language']['login_member']; ?>',360,170,e);
			
			$('#join_member').click(function(){
				$('#box_mask').remove();
				$('#box_body').empty();
				$('#box_body').remove();
				register();
			});
			$('#member_forget').click(function(){
				$('#box_mask').remove();
				$('#box_body').empty();
				$('#box_body').remove();
				forget();
			});

			var logins=function(){
				var member_mail=$('#member_mail').val();
				var member_password=$('#member_password').val();
				if ($.trim(member_mail)==''){
					alert('<?php echo $this->_var['language']['mail_is_empty']; ?>');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('<?php echo $this->_var['language']['mail_is_error']; ?>');
					return false;
				}
				if ($.trim(member_password)==''){
					alert('<?php echo $this->_var['language']['password_is_empty']; ?>');
					return false;
				}
				if (member_password.length<6&&member_password.length>20){
					alert('<?php echo $this->_var['language']['member_password_text']; ?>');
					return false;
				}
				$.ajax({
					type:"GET",
					url:"member.php?action=login_ok&member_mail="+encodeURI(member_mail)+"&member_password="+encodeURI(member_password)+"&r="+Math.random(), 
					dataType:"text",
					async:false,
					success:function(e){
						if(e=='error:mail_is_empty'){
							alert('<?php echo $this->_var['language']['mail_is_empty']; ?>');
							return false;
						}else if(e=='error:mail_is_error'){
							alert('<?php echo $this->_var['language']['mail_is_error']; ?>');
							return false;
						}else if(e=='error:password_is_empty'){
							alert('<?php echo $this->_var['language']['password_is_empty']; ?>');
							return false;
						}else if(e=='error:account_is_not_activate'){
							alert('<?php echo $this->_var['language']['account_is_not_activate']; ?>');
							return false;
						}else if(e=='error:account_is_lock'){
							alert('<?php echo $this->_var['language']['account_is_lock']; ?>');
							return false;
						}else if(e=='error:login_failed'){
							alert('<?php echo $this->_var['language']['login_failed']; ?>');
							return false;
						}
						location.reload();
					}
				});
			};
			/*回车登陆管理*/
			$('#member_password,#member_mail').keydown(function(event){
				var event = event||window.event;
				var keycode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;
				if(keycode==13){
					logins();
				}
			});
			$("#login_submit").click(function(){
				logins();
			});
		}//end request form success
	});//end request form
}
function forget(){
	$.ajax({
		type:"GET",
		url:"member.php?action=forget&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('<?php echo $this->_var['language']['member_forget']; ?>',360,140,e);

			var forget_submit=function(){
				var member_mail=$('#member_mail').val();
				var member_safecode=$('#member_safecode').val();
				if ($.trim(member_mail)==''){
					alert('<?php echo $this->_var['language']['mail_is_empty']; ?>');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('<?php echo $this->_var['language']['mail_is_error']; ?>');
					return false;
				}
				if ($.trim(member_safecode)==''){
					alert('<?php echo $this->_var['language']['safecode_is_empty']; ?>');
					return false;
				}
				$.ajax({
					type:"GET",
					url:"member.php?action=forget_ok&member_mail="+encodeURI(member_mail)+"&member_safecode="+encodeURI(member_safecode)+"&r="+Math.random(), 
					dataType:"text",
					async:false,
					success:function(e){
						alert(e);
						location.reload();
					}
				});
			};
	
			/*回车登陆管理*/
			$('#member_mail,#member_safecode').keydown(function(event){
				var event = event||window.event;
				var keycode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;
				if(keycode==13){
					forget_submit();
				}
			});
			$("#forget_submit_button").click(function(){
				forget_submit();
			});


		}//end request form success
	});//end request form
}
function register(){
	$.ajax({
		type:"GET",
		url:"member.php?action=register&r="+Math.random(),
		dataType:"text",
		async:false,
		success:function(e){
			box('<?php echo $this->_var['language']['join_member']; ?>',380,370,e);
			$("#member_mail").blur(function(){
				$.ajax({
					type:"GET",
					url:"member.php?action=check_member_mail&member_mail="+encodeURI(this.value)+"&r="+Math.random(), dataType:"text",async:false,success:function (e){	
					if (e==1) {
						$("#errMsg_member_mail").html("<img src='images/no.gif' align='absmiddle'/>");
					}else{
						$("#errMsg_member_mail").html("<img src='images/yes.gif' align='absmiddle'/>");
					}
				}});
			});

			$("#member_nickname").blur(function(){
				$.ajax({
					type:"GET",
					url:"member.php?action=check_member_nickname&member_nickname="+encodeURI(this.value)+"&r="+Math.random(), dataType:"text",async:false,success:function (e){
					if (e==1) {
						$("#errMsg_member_nickname").html("<img src='images/no.gif' align='absmiddle'/>");
					}else{
						$("#errMsg_member_nickname").html("<img src='images/yes.gif' align='absmiddle'/>");
					}
				}}); 
			});
			$("#member_password").blur(function(){
				var Mcolor = "#FFF",Lcolor = "#FFF",Hcolor = "#FFF";
				var m=0,Modes = 0,pwd=this.value;
				for (i=0; i<pwd.length; i++){
					var charType = 0;
					var t = pwd.charCodeAt(i);
					if (t>=48 && t <=57){
					  charType = 1;
					}else if (t>=65 && t <=90){
					  charType = 2;
					}else if (t>=97 && t <=122){
					  charType = 4;
					}else{
					  charType = 4;
					 }
					Modes |= charType;
				}

				for (i=0;i<4;i++){
					if(Modes & 1)m++;
					Modes>>>=1;
				}

				if (pwd.length<=4){
					m = 1;
				}

				switch(m){
				case 1 :
				  Lcolor = "2px solid red";
				  Mcolor = Hcolor = "2px solid #DADADA";
				break;
				case 2 :
				  Mcolor = "2px solid #f90";
				  Lcolor = Hcolor = "2px solid #DADADA";
				break;
				case 3 :
				  Hcolor = "2px solid #3c0";
				  Lcolor = Mcolor = "2px solid #DADADA";
				break;
				case 4 :
				  Hcolor = "2px solid #3c0";
				  Lcolor = Mcolor = "2px solid #DADADA";
				break;
				default :
				  Hcolor = Mcolor = Lcolor = "";
				break;
				}
				if (document.getElementById("pwd_lower")){
					document.getElementById("pwd_lower").style.borderBottom  = Lcolor;
					document.getElementById("pwd_middle").style.borderBottom = Mcolor;
					document.getElementById("pwd_high").style.borderBottom   = Hcolor;
				}
			});
			$("#register_submit").click(function(){
				var member_mail=$('#member_mail').val();
				var member_password=$('#member_password').val();
				var member_password_confirm=$('#member_password_confirm').val();
				var member_safecode=$('#member_safecode').val();
				var member_nickname=$('#member_nickname').val();
				if ($.trim(member_mail)==''){
					alert('<?php echo $this->_var['language']['mail_is_empty']; ?>');
					return false;
				}
				var reg=/([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/;
				if(!reg.test(member_mail)){
					alert('<?php echo $this->_var['language']['mail_is_error']; ?>');
					return false;
				}
				if ($.trim(member_password)==''){
					alert('<?php echo $this->_var['language']['password_is_empty']; ?>');
					return false;
				}
				if (member_password.length<6&&member_password.length>20){
					alert('<?php echo $this->_var['language']['member_password_text']; ?>');
					return false;
				}
				if ($.trim(member_password)!=$.trim(member_password_confirm)){
					alert('<?php echo $this->_var['language']['password_is_error']; ?>');
					return false;
				}
				if ($.trim(member_nickname)==''){
					alert('<?php echo $this->_var['language']['nickname_is_empty']; ?>');
					return false;
				}
				if (member_password.length<2&&member_password.length>10){
					alert('<?php echo $this->_var['language']['nickname_is_error']; ?>');
					return false;
				}
				if ($.trim(member_safecode)==''){
					alert('<?php echo $this->_var['language']['safecode_is_empty']; ?>');
					return false;
				}
				if (member_safecode.length<2&&member_safecode.length>10){
					alert('<?php echo $this->_var['language']['safecode_is_error']; ?>');
					return false;
				}
				$.ajax({type:"GET", url:"member.php?action=register_ok&member_mail="+encodeURI(member_mail)+"&member_password="+encodeURI(member_password)+"&member_password_confirm="+encodeURI(member_password_confirm)+"&member_nickname="+encodeURI(member_nickname)+"&member_safecode="+encodeURI(member_safecode)+"&r="+Math.random(), dataType:"text",async:false,success:function(e){
					if(e=='error:mail_is_empty'){
						alert('<?php echo $this->_var['language']['mail_is_empty']; ?>');
						return false;
					}else if(e=='error:mail_is_error'){
						alert('<?php echo $this->_var['language']['mail_is_error']; ?>');
						return false;
					}else if(e=='error:mail_is_occupy'){
						alert('<?php echo $this->_var['language']['mail_is_occupy']; ?>');
						return false;
					}else if(e=='error:password_is_empty'){
						alert('<?php echo $this->_var['language']['password_is_empty']; ?>');
						return false;
					}else if(e=='error:password_is_error'){
						alert('<?php echo $this->_var['language']['password_is_error']; ?>');
						return false;
					}else if(e=='error:safecode_is_empty'){
						alert('<?php echo $this->_var['language']['safecode_is_empty']; ?>');
						return false;
					}else if(e=='error:nickname_is_empty'){
						alert('<?php echo $this->_var['language']['nickname_is_empty']; ?>');
						return false;
					}else if(e=='error:nickname_is_occupy'){
						alert('<?php echo $this->_var['language']['nickname_is_occupy']; ?>');
						return false;
					}
					location.reload();
					get_member_info();
				}});
			});

		}//end request form success
	});//end request form
}


function get_member_info(){
	$.ajax({
	type:"GET",
	url:"member.php?action=member_info&r="+Math.random(),
	dataType:"text",
	async:false,
	success:function(e){
		$('#member_info').html(e);
		$('#logout').click(function(){
			$.ajax({type:"GET", url:"member.php?action=logout&r="+Math.random(), dataType:"text",async:false,success:function (){	
				get_member_info();
			}});
		});
	}});	
}
get_member_info();
</script>
</div>
		<?php endif; ?>
</div>
<?php endif; ?>
<div class="blank"></div>