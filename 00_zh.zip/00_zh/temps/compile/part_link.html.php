<?php if ($this->_var['link']): ?>
	<div id="link-box">
	<?php $_from = $this->_var['link']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link_0_86443800_1690270790');if (count($_from)):
    foreach ($_from AS $this->_var['link_0_86443800_1690270790']):
?>
		<a href="<?php echo $this->_var['link_0_86443800_1690270790']['url']; ?>" target="_blank" title="<?php echo $this->_var['link_0_86443800_1690270790']['text']; ?>">
		<?php if ($this->_var['link_0_86443800_1690270790']['logo']): ?>
		<img src="uploads/<?php echo $this->_var['link_0_86443800_1690270790']['logo']; ?>" alt=""/>
		<?php else: ?>
		<?php echo $this->_var['link_0_86443800_1690270790']['name']; ?>
		<?php endif; ?>
		</a>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		<div class="clear"></div>
	</div>
<?php endif; ?>

