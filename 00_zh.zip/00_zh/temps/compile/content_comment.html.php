<?php if ($this->_var['comment_list']): ?>
<div class="box">		
<?php $_from = $this->_var['comment_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comment');if (count($_from)):
    foreach ($_from AS $this->_var['comment']):
?>
<table width="100%" cellspacing="5" cellpadding="0">
<tr>
<td align="center" valign="top" width="60">
	<img src="<?php if ($this->_var['comment']['photo']): ?>uploads/<?php echo $this->_var['comment']['photo']; ?><?php else: ?>images/unknown.gif<?php endif; ?>" style="display:block;border:1px solid #eee;padding:1px;width:50px;height:50px;"/>
	<?php if ($this->_var['comment']['nickname']): ?><?php echo $this->_var['comment']['nickname']; ?><?php else: ?><?php echo $this->_var['language']['comment_anonymous']; ?><?php endif; ?><br />
	<?php if ($this->_var['content_info']['is_comment'] && $this->_var['comment_permissions'] && $this->_var['content_info']['password'] == ''): ?>
	<a href="javascript:;" onclick="comment_reply(<?php echo $this->_var['comment']['id']; ?>,event)"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_reply.gif" /></a>
	<?php endif; ?>
<?php if ($this->_var['template']['session']['admin_id'] > 0 || $this->_var['template']['session']['member_id'] == $this->_var['comment']['member_id']): ?>
<a href="javascript:;" onclick="comment_edit(<?php echo $this->_var['comment']['id']; ?>,event)"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_edit.gif" /></a>
<a href="javascript:;" onclick="comment_delete(<?php echo $this->_var['comment']['id']; ?>)"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_delete.gif" /></a>
<?php endif; ?>
</td>
<td valign="top">
<div style="font-size:11px;color:#999">
<b style="color:#3D8403">[# <?php echo $this->_var['comment']['no']; ?> <?php echo $this->_var['language']['comment_floor']; ?>]</b>&nbsp;&nbsp;
<?php echo $this->_var['language']['comment_time']; ?><?php echo $this->_var['comment']['time']; ?>&nbsp;&nbsp;
<?php echo $this->_var['language']['comment_from']; ?><?php echo $this->_var['comment']['ip_address']; ?>
</div>
<span id="comment_content_<?php echo $this->_var['comment']['id']; ?>"><?php echo $this->_var['comment']['content']; ?></span>
	<?php if ($this->_var['comment']['reply']): ?>
		<div class="blank"></div>
		<div style="color:red"><?php echo $this->_var['language']['comment_admin']; ?><?php echo $this->_var['comment']['reply']; ?></div>
	<?php endif; ?>
</td>
</tr>
</table>
<div class="line"></div>

<?php if ($this->_var['comment']['children']): ?>
	<?php $_from = $this->_var['comment']['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');if (count($_from)):
    foreach ($_from AS $this->_var['child']):
?>
	<table width="100%" cellspacing="5" cellpadding="0">
	<tr>
<td align="right" width="60">
	<img src="<?php if ($this->_var['child']['photo']): ?>uploads/<?php echo $this->_var['child']['photo']; ?><?php else: ?>images/unknown.gif<?php endif; ?>" style="display:block;border:1px solid #eee;padding:1px;width:30px;height:30px;"/>
	<?php if ($this->_var['child']['nickname']): ?><?php echo $this->_var['child']['nickname']; ?><?php else: ?><?php echo $this->_var['language']['anonymous']; ?><?php endif; ?><br />
	<?php if ($this->_var['template']['session']['admin_id'] > 0 || $this->_var['template']['session']['member_id'] == $this->_var['child']['member_id']): ?>
	<a href="javascript:;" onclick="comment_edit(<?php echo $this->_var['child']['id']; ?>,event)"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_edit.gif" /></a>
	<a href="javascript:;" onclick="comment_delete(<?php echo $this->_var['child']['id']; ?>)"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_delete.gif" /></a>
	<?php endif; ?>
	
	</td>
	<td valign="top">
	<div style="font-size:11px;color:#999">
	<b style="color:#3D8403">[# <?php echo $this->_var['comment']['no']; ?> <?php echo $this->_var['language']['comment_floor']; ?> <?php echo $this->_var['child']['no']; ?> <?php echo $this->_var['language']['comment_number']; ?>]</b>&nbsp;&nbsp;

	<?php echo $this->_var['language']['comment_time']; ?><?php echo $this->_var['child']['time']; ?>&nbsp;
	<?php echo $this->_var['language']['comment_from']; ?><?php echo $this->_var['child']['ip_address']; ?>

	
	</div>
	<span id="comment_content_<?php echo $this->_var['child']['id']; ?>"><?php echo $this->_var['child']['content']; ?></span>
		<?php if ($this->_var['comment']['reply']): ?>
			<div class="blank"></div>
			<div style="color:red"><?php echo $this->_var['language']['comment_admin']; ?><?php echo $this->_var['child']['reply']; ?></div>
		<?php endif; ?>
	</td>
	
	</tr>
	</table>
	<div class="line"></div>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
	<?php endif; ?>

<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
<div class="blank"></div>
<?php echo $this->_var['pagebar']; ?>
			</div>
		</div>
		<div class="blank"></div>
<?php endif; ?>
