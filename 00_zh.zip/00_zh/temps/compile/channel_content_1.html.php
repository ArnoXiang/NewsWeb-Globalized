<h3  class="content_title"><?php echo $this->_var['content_info']['title']; ?></h3>
<div class="content_info">
	<table width="100%">
	<tr>
	<td width="18">
<?php if ($this->_var['prev'] != ''): ?>
<a href="<?php echo $this->_var['prev']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/prev.gif" alt=""/></a>
<?php endif; ?>
	</td>
	<td align="center"  height="28"><?php echo $this->_var['language']['content_time']; ?><?php echo $this->_var['content_info']['time']; ?>&nbsp;<?php echo $this->_var['language']['content_click_count']; ?><?php echo $this->_var['content_info']['click_count']; ?><?php echo $this->_var['language']['content_click_count_unit']; ?>&nbsp;
	
	<span class="small" id="fontSmall" onclick="change_font(0)">T</span> <span class="big" id="fontBig" onclick="change_font(1)">T</span>

	<img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/print.gif" style="cursor:pointer" alt="" align="absmiddle" onclick="window.print()"/>
	</td>
	<td width="18">
	<?php if ($this->_var['next'] != ''): ?>
	<a href="<?php echo $this->_var['next']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/next.gif" alt=""/></a>
<?php endif; ?>
	</td>
	</tr>
	</table>
</div>
<div class="content_description"><?php echo $this->_var['content_info']['description']; ?></div>
<div class="content_text" id="content_text"><?php echo $this->_var['content_info']['text']; ?></div>

<?php if ($this->_var['content_info']['links']): ?>
<table width="98%" cellpadding="5" cellspacing="1" bgcolor="#eeeeee" style="margin:auto">
<tr>
<td width="80" bgcolor="#f4f4f4" height="30" align="center"><?php echo $this->_var['language']['content_links']; ?></td>
<td bgcolor="#ffffff">&nbsp;
	<?php $_from = $this->_var['content_info']['links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');if (count($_from)):
    foreach ($_from AS $this->_var['link']):
?>
			&nbsp;<a href="<?php echo $this->_var['link']['url']; ?>" target="_blank"><?php echo $this->_var['link']['url']; ?></a>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</td>
</tr>
</table>
<?php endif; ?>
<div class="blank"></div>
<?php if ($this->_var['content_info']['attachments']): ?>
<table width="98%" cellpadding="5" cellspacing="1" bgcolor="#eeeeee" style="margin:auto">
<tr>
<td width="80" bgcolor="#f4f4f4" height="30" align="center"><?php echo $this->_var['language']['content_attachment']; ?></td>
<td bgcolor="#ffffff">&nbsp;
	<?php $_from = $this->_var['content_info']['attachments']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'attachment');if (count($_from)):
    foreach ($_from AS $this->_var['attachment']):
?>
			<a href="uploads/<?php echo $this->_var['attachment']['name']; ?>" target="_blank"><?php echo $this->_var['attachment']['name']; ?></a>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</td>
</tr>
</table>
<div class="blank"></div>
<?php endif; ?>

<table cellspacing="5" cellpadding="0" style="margin:auto">
<tr>
<td>
	<table cellspacing="0" cellpadding="0">
	<tr><td bgcolor="#2A5388" align="center" style="font:bold 1em Arial;color:#fff;width:50px;height:30px;" id="support"><?php echo $this->_var['content_info']['support']; ?></td><td bgcolor="#ffffff" align="center"  style="border:1px solid #eee;border-left:none;width:50px;cursor:pointer" onclick="support(<?php echo $this->_var['content_info']['id']; ?>)"><?php echo $this->_var['language']['content_support']; ?></td></tr>
	</table>
	</td>
	<td>
	<table cellspacing="0" cellpadding="0">
	<tr><td bgcolor="#2A5388" align="center" style="font:bold 1em Arial;color:#fff;width:50px;height:30px;" id="against"><?php echo $this->_var['content_info']['against']; ?></td><td bgcolor="#ffffff" align="center" style="border:1px solid #eee;border-left:none;width:50px;cursor:pointer" onclick="against(<?php echo $this->_var['content_info']['id']; ?>)"><?php echo $this->_var['language']['content_against']; ?></td></tr>
	</table>
</td></tr>
	</table>

<script type="text/javascript">
$(function(){
	$.ajax({
		url:'content.php?action=ajax.support&mode=read&id=<?php echo $this->_var['content_info']['id']; ?>',
		type:'GET',
		success:function(e){
			if (e!='ERROR'){
				$('#support').html(e);
			}
		}
	});
	$.ajax({
		url:'content.php?action=ajax.against&mode=read&id=<?php echo $this->_var['content_info']['id']; ?>',
		type:'GET',
		success:function(e){
			if (e!='ERROR'){
				$('#against').html(e);
			}
		}
	});
});
function copy() {
    if (window.clipboardData) {
        window.clipboardData.setData("Text",arguments[0]);
		 alert('<?php echo $this->_var['language']['content_copy_link_success']; ?>');
    }else{
		 alert('<?php echo $this->_var['language']['content_copy_link_failed']; ?>');
    }
}
function change_font(type){
		if(type==0){
			$("#content_text").css("font-size","14px");
			$("#content_text > *").css("font-size","14px");
		}else{
			$("#content_text").css("font-size","16px");
			$("#content_text > *").css("font-size","16px");
		}
}
function support(id)
{
	if (!GetCookie('content_'+id))
	{	
		$.ajax({
			url:'content.php?action=ajax.support&id='+id,
			type:'GET',
			success:function(e){
				if (e!='ERROR'){
					$('#support').html(e);
					SetCookie('content_'+id,true,365);
				}
			}
		});
	}else{
		alert('<?php echo $this->_var['language']['content_have_participated']; ?>');
	}
}
function against(id)
{
	if (!GetCookie('content_'+id))
	{	
		$.ajax({
			url:'content.php?action=ajax.against&id='+id,
			type:'GET',
			success:function(e){
				if (e!='ERROR'){	
					$('#against').html(e);
					SetCookie('content_'+id,true,365);
				}
			}
		});
	}else{
		alert('<?php echo $this->_var['language']['content_have_participated']; ?>');
	}
}
function GetCookie(){
		var m='';
		if(window.RegExp)
		{
			var re=new RegExp(';\\s*'+arguments[0]+'=([^;]*)','i');
			m=re.exec(';'+document.cookie);
		}
		return(m?unescape(m[1]):'');
}	
function SetCookie(){
	var $Date=new Date();
	var $Expires=($Date.setTime($Date.getTime()+(arguments[2]*86400000)));
	var $Time=$Date.toGMTString();
	var exp=';expires='+ $Time;
	document.cookie=arguments[0]+'='+escape(arguments[1])+exp+';path=/';
}
</script>