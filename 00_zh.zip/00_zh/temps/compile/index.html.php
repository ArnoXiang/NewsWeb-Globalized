<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['config']['site_keywords']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['config']['site_description']); ?>" />
<link rel="stylesheet" href="templates/<?php echo $this->_var['config']['site_template']; ?>/style.css" />
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
<div id="center">
	<div id="main">
		<div class="panel">
		<?php if ($this->_var['channel_panel']): ?>
			<?php $_from = $this->_var['channel_panel']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'channel');if (count($_from)):
    foreach ($_from AS $this->_var['channel']):
?>
				<div style="margin:2px;width:340px;overflow:hidden;float:left">
				<div class="panel_caption">
					<a href="<?php echo $this->_var['channel']['url']; ?>"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/more.gif" alt="" align="absmiddle"/></a>
					<?php echo $this->_var['channel']['name']; ?>
				</div>
				<?php echo $this->_var['channel']['content']; ?>
				</div>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		<?php else: ?>
			&nbsp;
		<?php endif; ?>
		</div>
		<div><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/home_EN.jpg"></div>
	</div>
	<div id="in"></div>
	<div id="side">
		<?php echo $this->fetch('part_content.html'); ?>
		<?php echo $this->fetch('part_comment.html'); ?>
		<?php echo $this->fetch('part_vote.html'); ?>
	</div>
	<div class="clear"></div>
	 <div class="blank"></div>
	<?php echo $this->fetch('part_link.html'); ?>
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>