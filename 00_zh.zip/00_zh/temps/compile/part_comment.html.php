<div class="box">
<div class="box_title"><?php echo $this->_var['language']['new_comment']; ?></div>
<?php if ($this->_var['content_comment']): ?>
	<div class="side_list">
		<?php $_from = $this->_var['content_comment']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comment');if (count($_from)):
    foreach ($_from AS $this->_var['comment']):
?>
			<a href="<?php echo $this->_var['comment']['url']; ?>" title="<?php echo $this->_var['comment']['time']; ?>"><?php echo $this->_var['comment']['content']; ?></a>
		<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
	</div>
<?php endif; ?>
</div>
<div class="blank"></div>
