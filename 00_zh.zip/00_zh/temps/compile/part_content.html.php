<div class="box">
	<div class="tab_tag">
		<div id="tab_tag_1" class="current" onclick="tab('tab',1,2)"><?php echo $this->_var['language']['hot_content']; ?></div>
		<div id="tab_tag_2" onclick="tab('tab',2,2)"><?php echo $this->_var['language']['best_content']; ?></div>
		<P class="clearleft"></P>
	</div>
	<div id="tab_body_1">
	<?php if ($this->_var['hot_content']): ?>
		<div class="side_list">
		<?php $_from = $this->_var['hot_content']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'content_0_86086900_1690270790');if (count($_from)):
    foreach ($_from AS $this->_var['content_0_86086900_1690270790']):
?>
			<a href="<?php echo $this->_var['content_0_86086900_1690270790']['url']; ?>"><?php echo $this->_var['content_0_86086900_1690270790']['title']; ?></a>
		<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		</div>
	<?php endif; ?>
	</div>
	<div id="tab_body_2" style="display:none">
	<?php if ($this->_var['best_content']): ?>
		<div class="side_list">
		<?php $_from = $this->_var['best_content']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'content_0_86100900_1690270790');if (count($_from)):
    foreach ($_from AS $this->_var['content_0_86100900_1690270790']):
?>
			<a href="<?php echo $this->_var['content_0_86100900_1690270790']['url']; ?>"><?php echo $this->_var['content_0_86100900_1690270790']['title']; ?></a>
		<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		</div>
	<?php endif; ?>
	</div>
</div>
<div class="blank"></div>