 <div id="footer">
	<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
	<td align="left">
	
	&nbsp;&copy;&nbsp;2005-2011环球文章汇<br />
	基于WEEDCMS V5.5管理系统
	
	</td><td align="right" valign="top">
	<?php if ($this->_var['bottom_menu']): ?>
	<?php $_from = $this->_var['bottom_menu']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'menu_0_50687100_1690272668');$this->_foreach['bottom_menu'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['bottom_menu']['total'] > 0):
    foreach ($_from AS $this->_var['menu_0_50687100_1690272668']):
        $this->_foreach['bottom_menu']['iteration']++;
?>
	<a href="<?php echo $this->_var['menu_0_50687100_1690272668']['link']; ?>" <?php if ($this->_var['menu_0_50687100_1690272668']['target'] == 1): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['menu_0_50687100_1690272668']['name']; ?></a>
	<?php if (! ($this->_foreach['bottom_menu']['iteration'] == $this->_foreach['bottom_menu']['total'])): ?>
	<span class="split">|</span>
	<?php endif; ?>
	<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
	<?php endif; ?>
	<?php if ($this->_var['config']['site_icp']): ?>
	<br /><a href="http://www.miibeian.gov.cn/" target="_blank"><?php echo $this->_var['config']['site_icp']; ?></a>
	<?php endif; ?>
	</td>
	</tr>
	</table>
</div>