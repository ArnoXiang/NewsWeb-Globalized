<?php if ($this->_var['channel_category']): ?>
	<div class="box">
		<div class="box_title"><?php echo $this->_var['language']['channel_category']; ?></div>
		<div class="category_list">
			<?php $_from = $this->_var['channel_category']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'first');if (count($_from)):
    foreach ($_from AS $this->_var['first']):
?>
				<a href="<?php echo $this->_var['first']['url']; ?>" class="big"><?php echo $this->_var['first']['name']; ?></a>
				<?php $_from = $this->_var['first']['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'second');if (count($_from)):
    foreach ($_from AS $this->_var['second']):
?>
					<a href="<?php echo $this->_var['second']['url']; ?>" class="small" <?php if ($_REQUEST['category_id'] == $this->_var['second']['id']): ?>style="font-weight:bold;color:red"<?php endif; ?>><?php echo $this->_var['second']['name']; ?></a>
				<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		</div>
	</div>
	<div class="blank"></div>
<?php endif; ?>