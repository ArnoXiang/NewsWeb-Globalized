<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['language']['position_feedback']; ?> - <?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['config']['site_keywords']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['config']['site_description']); ?>" />
<link rel="stylesheet" href="templates/<?php echo $this->_var['config']['site_template']; ?>/style.css" />
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript">
function feedback_post(){
		if($('#feedback_authcode').val()==''){
			alert('<?php echo $this->_var['language']['feedback_authcode_is_empty']; ?>');
			return false;
		}
		if($('#feedback_name').val()==''){
			alert('<?php echo $this->_var['language']['feedback_name_is_empty']; ?>');
			return false;
		}
		if($('#feedback_content').val()==''){
			alert('<?php echo $this->_var['language']['feedback_content_is_empty']; ?>');
			return false;
		}	
}
function on_focus(obj,text){
	if($(obj).val()==text){
		$(obj).val('');
	}
	$(obj).css('color','#000');
}
function on_blur(obj,text){
	if($(obj).val()==''){
		$(obj).val(text);
	}
	$(obj).css('color','#999');
}
</script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
<div id="center">
	<div id="main">
		<div class="box">
		<?php if ($this->_var['feedback']): ?>
			<?php $_from = $this->_var['feedback']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'feedback_0_19834700_1690272168');if (count($_from)):
    foreach ($_from AS $this->_var['feedback_0_19834700_1690272168']):
?>
				<div class="feedback_list">
				<div class="feedback_caption">
					<span><?php echo $this->_var['feedback_0_19834700_1690272168']['name']; ?></span>&nbsp;
					<small>(<?php echo $this->_var['feedback_0_19834700_1690272168']['address']; ?>,<?php echo $this->_var['feedback_0_19834700_1690272168']['time']; ?>)</small>
				</div>
				<div class="feedback_content">
					<?php echo $this->_var['feedback_0_19834700_1690272168']['content']; ?>
					<?php if ($this->_var['feedback_0_19834700_1690272168']['reply']): ?>
						<div class="feedback_reply"><b><?php echo $this->_var['language']['form_feedback_reply']; ?></b><br/><?php echo $this->_var['feedback_0_19834700_1690272168']['reply']; ?>&nbsp;<small>(<?php echo $this->_var['feedback_0_19834700_1690272168']['reply_time']; ?>)</small></div>
					<?php endif; ?>
				</div>
 
				
			
				</div>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
			<?php echo $this->_var['pagebar']; ?>
	<?php endif; ?>
	<form action="feedback.php?action=insert" method="post" onsubmit="return feedback_post()">
<table cellpadding="5" cellspacing="5">
 <tr>
 <td colspan="2"><input type="text" name="feedback_name" id="feedback_name" style="width:120px;padding:3px;color:#999" class="input" value="<?php if ($_SESSION['member_nickname']): ?><?php echo $_SESSION['member_nickname']; ?><?php else: ?><?php echo $this->_var['language']['form_feedback_name']; ?><?php endif; ?>" onfocus="on_focus(this,'<?php echo $this->_var['language']['form_feedback_name']; ?>')" onblur="on_blur(this,'<?php echo $this->_var['language']['form_feedback_name']; ?>')" /></td>
  </tr>
 <tr>
<td colspan="2"><textarea id="feedback_content" name="feedback_content" style="border-radius:5px;resize:none;padding:3px;width:675px;height:82px;overflow:auto;color:#999" class="textarea" onfocus="on_focus(this,'<?php echo $this->_var['language']['form_feedback_content']; ?>')" onblur="on_blur(this,'<?php echo $this->_var['language']['form_feedback_content']; ?>')"><?php echo $this->_var['language']['form_feedback_content']; ?></textarea></td>
</tr>

<tr>
<td><input type="text" name="feedback_authcode" id="feedback_authcode" style="width:120px;padding:3px;color:#999" class="input"onfocus="on_focus(this,'<?php echo $this->_var['language']['form_feedback_authcode']; ?>')" onblur="on_blur(this,'<?php echo $this->_var['language']['form_feedback_authcode']; ?>')" value="<?php echo $this->_var['language']['form_feedback_authcode']; ?>"/>&nbsp;<img src="authcode.php" alt="" align="absmiddle" onclick="this.src+='?'+Math.random()"/>
</td>
<td align="right">
<input type="submit" id="feedback_submit" value="<?php echo $this->_var['language']['submit']; ?>" class="button"/>
</td>
</tr>
</form>
</table>
		</div>
	</div>
	<div id="in"></div>
	<div id="side">
		<?php echo $this->fetch('part_vote.html'); ?>
	</div>
	<div class="clear"></div>
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>