<?php if ($this->_var['content_list'] || $this->_var['best_content_list']): ?>
<table cellpadding="0" cellspacing="0" class="channel_list_1">
<?php $_from = $this->_var['best_content_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'content');if (count($_from)):
    foreach ($_from AS $this->_var['content']):
?>
<tr>
<td  class="no"><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_best.png" alt="" align="absmiddle"/></td>
<td>
<?php if ($this->_var['content']['category_id'] > 0): ?>
[<a href="<?php echo $this->_var['content']['category_url']; ?>" style="font-weight:bold;color:green"><?php echo $this->_var['content']['category_name']; ?></a>]
<?php endif; ?>
<a href="<?php echo $this->_var['content']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['content']['title']; ?></a>
<?php if ($this->_var['content']['password']): ?><img src="images/lock.gif" alt="" align="absmiddle"/>&nbsp;<?php endif; ?>
<?php if ($this->_var['content']['is_new']): ?><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_new.gif" alt="" align="absmiddle"/><?php endif; ?>
</td>
<td class="time"><?php echo $this->_var['content']['time']; ?></td>
</tr>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>

<?php $_from = $this->_var['content_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'content');if (count($_from)):
    foreach ($_from AS $this->_var['content']):
?>
<tr>
<td class="no"><?php echo $this->_var['content']['no']; ?></td>
<td>
<?php if ($this->_var['content']['category_id'] > 0): ?>
[<a href="<?php echo $this->_var['content']['category_url']; ?>"  style="font-weight:bold;color:green"><?php echo $this->_var['content']['category_name']; ?></a>]
<?php endif; ?>
<a href="<?php echo $this->_var['content']['url']; ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['content']['title']; ?></a>
<?php if ($this->_var['content']['password']): ?><img src="images/lock.gif" alt="" align="absmiddle"/>&nbsp;<?php endif; ?>
<?php if ($this->_var['content']['is_new']): ?><img src="templates/<?php echo $this->_var['config']['site_template']; ?>/images/icon_new.gif" alt="" align="absmiddle"/><?php endif; ?>
</td>
<td class="time"><?php echo $this->_var['content']['time']; ?></td>
</tr>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</table>
<?php echo $this->_var['pagebar']; ?>
<?php else: ?>
<div style="text-align:center;line-height:50px;color:#ccc"><?php echo $this->_var['language']['nodata']; ?></div>
<?php endif; ?>
