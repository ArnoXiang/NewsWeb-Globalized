<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['content_info']['title']; ?> - <?php echo $this->_var['channel_info']['name']; ?> - <?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['content_info']['keywords']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['content_info']['description']); ?>" />
<link rel="stylesheet" href="templates/<?php echo $this->_var['config']['site_template']; ?>/style.css" />
<script type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
<div id="center">
	<div id="main">
		<div class="box">
		<?php if ($this->_var['content_info']['password']): ?>
<script type="text/javascript">
function get_content_data(content_id){
	var password=$("#password_"+content_id).val();
	if($.trim(password)==''){
		alert('<?php echo $this->_var['language']['content_password_is_empty']; ?>');return;
	}
	$.ajax({
		type:"GET",
		url:"content.php?action=get_content&content_id="+content_id+"&password="+password+"&r="+Math.random(),
		dataType:"text",
		success:function(content){
			if (content=='ERROR'){
				alert('<?php echo $this->_var['language']['content_password_is_error']; ?>');return;
			}
			$("#content_"+content_id).html(arguments[0]);
	}});
}
</script>
	    <div id="content_<?php echo $this->_var['content_info']['id']; ?>">
		<br>
		<br>
		<div  style="font-size:14px;text-align:center">
			<table cellspacing="5" cellpadding="5">
			<tr>
			<td><?php echo $this->_var['language']['content_please_put_password']; ?></td>
			<td><input id="password_<?php echo $this->_var['content_info']['id']; ?>" type="password" class="input" /></td>
			<td><input  onclick="get_content_data(<?php echo $this->_var['content_info']['id']; ?>)" type="submit" value="<?php echo $this->_var['language']['submit']; ?>" class="button" /></td>
			</tr>
			</table>
		 </div>
		<br>
		<br>
		&nbsp;
	    </div>
   <?php else: ?>
			<?php echo $this->_var['content']; ?>
	 <?php endif; ?>
		</div>
		<div class="blank"></div>
		<?php if ($this->_var['content_info']['is_comment'] && $this->_var['comment_permissions'] && $this->_var['content_info']['password'] == ''): ?>
		<div id="comment_list"></div>
<div class="box">
			<table cellspacing="5" cellpadding="5" width="100%">
			<tr><td colspan="2"><textarea id="comment_content" style="overflow:auto;width:670px;height:60px;padding:5px;border:1px solid #ccc;background:#f4f4f4" /></textarea></td></tr>
			
			<tr><td align="left">
			<input type="text" name="comment_authcode" id="comment_authcode" style="width:60px;padding:3px;" class="input"/>&nbsp;<img src="authcode.php" alt="" align="absmiddle" id="comment_authcode_image" onclick="this.src+='?'+Math.random()"/>
			<span id="emot"></span>
			<script type="text/javascript">
			for(var i=1;i<22;i++){
				var img=new Image();
					img.src="images/emot"+i+".gif";
					img.style.cursor='pointer';
					img.style.margin='1px';
					img.align='absmiddle';
					img.no=i;
					img.onclick=function(){
						put_emot(event,this.no);
					}
					document.getElementById('emot').appendChild(img);
			}
			function put_emot(event,no){
				var o=document.getElementById('comment_content');
				var l=o.value.length;
					o.focus();
					if(typeof document.selection!="undefined"){
						document.selection.createRange().text='[e:'+no+']'; 
					}else{
						o.value=o.value.substr(0,o.selectionStart)+'[e:'+no+']'+o.value.substring(o.selectionStart,l);
					}			
			}
			</script>
			</td><td width="60"><input type="button" value="<?php echo $this->_var['language']['add_comment']; ?>" class="button" onclick="comment_insert()"/></td>
			</tr>
			</table>
		</div>
		<div class="blank"></div>
		<?php endif; ?>
		<script type="text/javascript">
		
		$(function(){
			get_comment();
		});
		function get_comment(page){
			if (page==undefined){
				page=1;
			}
			$.ajax({
				type:"GET",
				url:"comment.php?action=content_comment_list&content_id=<?php echo $this->_var['content_info']['id']; ?>&page="+page+"&r="+Math.random(),
				dataType:"text",
				success:function(){
					$("#comment_list").html(arguments[0]);
			}});			
		}
		function comment_insert(){
			var comment_authcode=$("#comment_authcode").val();
			if ($.trim(comment_authcode)==''){
				alert('<?php echo $this->_var['language']['comment_authcode_is_empty']; ?>');
				authcode_reload();
				return false;
			}
			var comment_content=$("#comment_content").val();
			if ($.trim(comment_content)==''){
				alert('<?php echo $this->_var['language']['comment_content_is_empty']; ?>');
				authcode_reload();
				return false;
			}
			if (comment_content.length<5||comment_content.length>80){
				alert('<?php echo $this->_var['language']['comment_content_is_error']; ?>');
				authcode_reload();
				return false;
			}
			$.ajax({
				type:"GET",
				url:"comment.php?action=content_comment_insert&content_id=<?php echo $this->_var['content_info']['id']; ?>&comment_content="+encodeURI(comment_content)+"&comment_authcode="+comment_authcode+"&r="+Math.random(),
				dataType:"text",
				success:function(e){
					if(e=='EMPTY:AUTHCODE'){
						alert('<?php echo $this->_var['language']['comment_authcode_is_empty']; ?>');
						authcode_reload();
						return false;
					}
					if(e=='ERROR:AUTHCODE'){
						alert('<?php echo $this->_var['language']['comment_authcode_is_error']; ?>');
						authcode_reload();
						return false;
					}
					if(e=='EMPTY:CONTENT'){
						alert('<?php echo $this->_var['language']['comment_content_is_empty']; ?>');
						authcode_reload();
						return false;
					}
					if(e=='WAIT'){
						alert('<?php echo $this->_var['language']['comment_wait']; ?>');
						authcode_reload();
					}
					get_comment();
					$('#comment_content').val("");
					authcode_reload();
			}});
		}
		function authcode_reload(){
			$('#comment_authcode_image').attr('src','authcode.php?'+Math.random());
		}
		
		var a=0,b;
		function comment_edit(comment_id,e){
			var pos=get_pos(e);
			if (a>0){
				$("#showbox_div"+b).remove();
			}
			var outer=$("<div/>").css({
				"top": pos.y,
				"left": pos.x,
				"position":"absolute",
				"overflow":"hidden",
				"display":"none"
			}).addClass("comment_box").attr("id","showbox_div"+a).appendTo("body").fadeIn("fast");
			var div=$("<div/>");
			$.ajax({
					type:"GET",
					url:"comment.php?action=content_comment_content&comment_id="+comment_id+"&r="+Math.random(),
					dataType:"text",
					success:function(e){
	 					div.html("<textarea id='comment_content_"+comment_id+"_textarea'>"+e+"</textarea><div style='text-align:right'><input type='button' value='<?php echo $this->_var['language']['submit']; ?>' id='showbox_submit'/><input type='button' value='<?php echo $this->_var['language']['cancel']; ?>' id='showbox_cancel'/></div>").appendTo(outer);
				//提交处理
			$("#showbox_submit").click(function(){
				var new_content=$("#comment_content_"+comment_id+"_textarea").val();
				if ($.trim(new_content)==''){
					alert('<?php echo $this->_var['language']['comment_content_is_empty']; ?>');
					return;
				}
				if (new_content.length<5||new_content.length>80){
					alert('<?php echo $this->_var['language']['comment_content_is_error']; ?>');
					return false;
				}
				$.ajax({
					type:"GET",
					url:"comment.php?action=content_comment_update&content_id=<?php echo $this->_var['content_info']['id']; ?>&comment_id="+comment_id+"&comment_content="+encodeURI(new_content)+"&r="+Math.random(),
					dataType:"text",
					success:function(){
						$("#comment_content_"+comment_id).html(new_content);
						outer.fadeOut(function(){
							div.remove();
						});
				}});	
			});
			//取消处理
			$("#showbox_cancel").click(function(){
				outer.fadeOut(function(){div.remove()});
			});
				}});
			b=a;
			a++;
		}
		//回复评论
		function comment_reply(comment_id,e){
			var pos=get_pos(e);
			if (a>0){
				$("#showbox_div"+b).remove();
			}
			var outer=$("<div/>").css({
				"top": pos.y,
				"left": pos.x,
				"position":"absolute",
				"overflow":"hidden",
				"display":"none"
			}).addClass("comment_box").attr("id","showbox_div"+a).appendTo("body").fadeIn("fast");

			var div=$("<div/>").html("<textarea id='comment_content_"+comment_id+"_textarea'></textarea><div style='text-align:right'><input type='button' value='<?php echo $this->_var['language']['submit']; ?>' id='showbox_submit'/><input type='button' value='<?php echo $this->_var['language']['cancel']; ?>' id='showbox_cancel'/></div>").appendTo(outer);
			//提交处理
			$("#showbox_submit").click(function(){
				var new_content=$("#comment_content_"+comment_id+"_textarea").val();
				if ($.trim(new_content)==''){
					alert('<?php echo $this->_var['language']['content_comment_is_empty']; ?>');
					return;
				}
				$.ajax({
					type:"GET",
					url:"comment.php?action=content_comment_reply&content_id=<?php echo $this->_var['content_info']['id']; ?>&comment_id="+comment_id+"&comment_content="+encodeURI(new_content)+"&r="+Math.random(),
					dataType:"text",
					success:function(e){
						if(e=='WAIT'){
							alert('<?php echo $this->_var['language']['comment_wait']; ?>');
						}
						get_comment();
						outer.fadeOut(function(){
							div.remove();
						});
				}});	
			});
			//取消处理
			$("#showbox_cancel").click(function(){
				outer.fadeOut(function(){div.remove()});
			});
			b=a;
			a++;
		}
		function comment_delete(comment_id){
			if(confirm('<?php echo $this->_var['language']['delete_confirm']; ?>')){
				$.ajax({
					type:"GET",
					url:"comment.php?action=content_comment_delete&content_id=<?php echo $this->_var['content_info']['id']; ?>&comment_id="+comment_id+"&r="+Math.random(),
					dataType:"text",
					success:function(){
						get_comment();
						$("#comment_count").html(parseInt($("#comment_count").html())-1);
				}});
			}
		}
		
		</script>
		<div class="blank"></div>
	</div>
	<div id="in"></div>
	<div id="side">
		<?php echo $this->fetch('part_category.html'); ?>
		<?php if ($this->_var['channel_info']['list_style'] != 5): ?>
			<?php echo $this->fetch('part_content.html'); ?>
		<?php endif; ?>
		<?php echo $this->fetch('part_vote.html'); ?>
	</div>
	<div class="clearleft"></div>
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
