<?php if ($_SESSION['member_id'] > 0): ?>
<?php if ($_SESSION['member_photo']): ?><img src="uploads/<?php echo $_SESSION['member_photo']; ?>" align="absmiddle" alt="" class="member_photo"/>&nbsp;<?php endif; ?><span class="member_nickname"><?php echo $_SESSION['member_nickname']; ?></span>(<?php echo $_SESSION['member_mail']; ?>)
<a href="member.php?action=edit_member"><?php echo $this->_var['language']['member_center']; ?></a>
	<span class="split">/</span>
<a href="#" id="logout"><?php echo $this->_var['language']['logout']; ?></a>
<?php else: ?>
<a href="javascript:login()"><?php echo $this->_var['language']['login_member']; ?></a>
	<span class="split">/</span>
<a href="javascript:register();"><?php echo $this->_var['language']['join_member']; ?></a>
<?php endif; ?>
