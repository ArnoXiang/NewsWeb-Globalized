<?php $_from = $this->_var['content_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'content');$this->_foreach['list'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['list']['total'] > 0):
    foreach ($_from AS $this->_var['content']):
        $this->_foreach['list']['iteration']++;
?>
<p class="channel_index_1">
<span><?php echo $this->_var['content']['time']; ?></span>
<?php if ($this->_var['content']['category_id'] > 0): ?>
[<a href="<?php echo $this->_var['content']['category_url']; ?>" style="font-weight:bold;color:green"  title="<?php echo htmlspecialchars($this->_var['content']['category_name']); ?>"><?php echo $this->_var['content']['category_name']; ?></a>]
<?php endif; ?>
<a href="<?php echo $this->_var['content']['url']; ?>"  title="<?php echo htmlspecialchars($this->_var['content']['title']); ?>" <?php if ($this->_var['content']['target']): ?>target="_blank"<?php endif; ?>><?php echo $this->_var['content']['title']; ?></a>
</p>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
