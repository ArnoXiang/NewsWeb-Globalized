<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['page_info']['title']; ?> - <?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<link rel="stylesheet" href="templates/<?php echo $this->_var['config']['site_template']; ?>/style.css" />
<script language="javascript" type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
<div id="center">

	
	<div id="main">
	<div class="box">
		<?php echo $this->_var['page_info']['content']; ?>
	</div>
	<div class="blank"></div>	
	</div>
	<div id="in"></div>
	<div id="side">
		<?php if ($this->_var['page_list']): ?>
		<ul class="page_list">
		<?php $_from = $this->_var['page_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'page');if (count($_from)):
    foreach ($_from AS $this->_var['page']):
?>
			<li class="parent"><a href="page.php?id=<?php echo $this->_var['page']['id']; ?>"><?php echo $this->_var['page']['title']; ?></a></li>
			<?php $_from = $this->_var['page']['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'page');if (count($_from)):
    foreach ($_from AS $this->_var['page']):
?>
				<li class="child"><a href="page.php?id=<?php echo $this->_var['page']['id']; ?>"><?php echo $this->_var['page']['title']; ?></a></li>
			<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
		</ul>
		<div class="blank"></div>
		<?php endif; ?>
		<?php echo $this->fetch('part_vote.html'); ?>
	</div>
	<div class="clearleft"></div>
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
