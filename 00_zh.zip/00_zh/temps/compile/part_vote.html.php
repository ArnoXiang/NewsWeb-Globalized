<?php if ($this->_var['vote']): ?>
<div class="box">
		<div class="box_title"><?php echo $this->_var['language']['vote']; ?></div>
<?php $_from = $this->_var['vote']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'vote_0_91533100_1690272997');if (count($_from)):
    foreach ($_from AS $this->_var['vote_0_91533100_1690272997']):
?>
<form action="vote.php?action=ok" method="post" style="padding:3px 10px">
<h4><?php echo $this->_var['vote_0_91533100_1690272997']['title']; ?></h4>
<div class="blank"></div>
 <?php $_from = $this->_var['vote_0_91533100_1690272997']['items']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'item');$this->_foreach['item'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['item']['total'] > 0):
    foreach ($_from AS $this->_var['item']):
        $this->_foreach['item']['iteration']++;
?>
	<label>
	<?php if ($this->_var['vote_0_91533100_1690272997']['mode'] == 1): ?>
	<input type="checkbox" name="item_id[]" value="<?php echo $this->_var['item']['id']; ?>" <?php if (($this->_foreach['item']['iteration'] - 1) == 0): ?>checked<?php endif; ?>/>
	<?php else: ?>
	<input type="radio" name="item_id" value="<?php echo $this->_var['item']['id']; ?>" <?php if (($this->_foreach['item']['iteration'] - 1) == 0): ?>checked<?php endif; ?>/>
	<?php endif; ?>
	<?php echo $this->_var['item']['title']; ?>&nbsp;(<?php echo $this->_var['item']['count']; ?>)
	</label>
	<div class="blank"></div>
 <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
  <input type="hidden" name="vote_mode" value="<?php echo $this->_var['vote_0_91533100_1690272997']['mode']; ?>" />
 <input type="hidden" name="vote_id" value="<?php echo $this->_var['vote_0_91533100_1690272997']['id']; ?>" />
  <div class="center">
  <input type="submit" value="<?php echo $this->_var['language']['submit']; ?>" class="button"/>
  </div>
  <div class="blank"></div>
 </form>

<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </div>
<div class="blank"></div>
<?php endif; ?>