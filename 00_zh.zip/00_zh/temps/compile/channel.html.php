<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $this->_var['channel_info']['name']; ?> - <?php echo $this->_var['config']['site_name']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="keywords" content="<?php echo htmlspecialchars($this->_var['channel_info']['name']); ?>" />
<meta name="description" content="<?php echo htmlspecialchars($this->_var['channel_info']['description']); ?>" />
<link rel="stylesheet" href="templates/<?php echo $this->_var['config']['site_template']; ?>/style.css" />
<script language="javascript" type="text/javascript" src="scripts/jquery.js"></script>
</head>
<body>
<?php echo $this->fetch('header.html'); ?>
<div id="center">
	<div id="main">
	<div class="panel">
		<?php if ($this->_var['channel_info']['banner']): ?>
			<img src="uploads/<?php echo $this->_var['channel_info']['banner']; ?>" />
		<?php endif; ?>
		<?php echo $this->_var['channel_content']; ?>
	</div>
	<div class="blank"></div>
	 <?php if ($this->_var['write_permissions']): ?>
  <div style="text-align:right"><input class="button"  type="button" value="<?php echo $this->_var['language']['channel_post']; ?>" onclick="location.href='content.php?action=add&channel_id=<?php echo $this->_var['channel_info']['id']; ?>'"></div>
<?php endif; ?>
	</div>
	<div id="in"></div>
	<div id="side">
		<?php echo $this->fetch('part_category.html'); ?>
		<?php if ($this->_var['channel_info']['list_style'] != 5): ?>
			<?php echo $this->fetch('part_content.html'); ?>
		<?php endif; ?>
		<?php echo $this->fetch('part_vote.html'); ?>
	</div>
	<div class="clear"></div>
</div>
<?php echo $this->fetch('footer.html'); ?>
</body>
</html>
