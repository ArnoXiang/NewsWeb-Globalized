<?php
/**
 * WEEDCMS 留言本
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月08日
*/
require_once'includes/global.php';
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once'includes/front.php';
if(isset($_GET['action'])){
	//提交留言
	if($_GET['action']=='insert'){
		$feedback_name=empty($_POST['feedback_name'])?'':addslashes(trim($_POST['feedback_name']));
		$feedback_content=empty($_POST['feedback_content'])?'':addslashes(trim($_POST['feedback_content']));
		$feedback_authcode=empty($_POST['feedback_authcode'])?'':addslashes(trim(strtolower($_POST['feedback_authcode'])));
		if($feedback_authcode!=@$_SESSION['authcode']){
			$_SESSION['authcode']=false;
			unset($_SESSION['authcode']);
			message(array('text'=>$language['feedback_authcode_is_error'],'link'=>''));
		}
		if(empty($feedback_authcode)){
			message(array('text'=>$language['feedback_authcode_is_empty'],'link'=>''));
		}
		if(empty($feedback_name)){
			message(array('text'=>$language['feedback_name_is_empty'],'link'=>''));
		}
		if(empty($feedback_content)){
			message(array('text'=>$language['feedback_content_is_empty'],'link'=>''));
		}
		$insert=array();
		$insert['feedback_name']=$feedback_name;
		$insert['feedback_content']=$feedback_content;
		$insert['feedback_reply']='';
		$insert['feedback_time']=$_SERVER['REQUEST_TIME'];
		$insert['feedback_ip']=get_ip();
		if($config['feedback_state']=='yes'){
			$insert['feedback_state']=0;
			$text=$language['feedback_insert_is_ok'];
		}else{
			$insert['feedback_state']=1;
			$text=$language['feedback_insert_is_success'];
		}
		$db->insert($db_prefix."feedback",$insert);
		message(array('text'=>$text,'link'=>create_uri("feedback")));
	}
}
//标注在线位置
set_online(create_uri("feedback"));
$feedback_list=array();
$sql="select * from ".$GLOBALS['db_prefix']."feedback where feedback_state=1";
$page_size=$config['feedback_size'];
$page_current=isset($_GET['page'])?intval($_GET['page']):1;
$count=$GLOBALS['db']->getcount($sql);
$res=$GLOBALS['db']->getall($sql." order by feedback_id DESC limit ".(($page_current-1)*$page_size).",".$page_size);
if($count>0){
	$no=$count-(($page_current-1)*$page_size);
	foreach($res as $row){
		$feedback_list[$row['feedback_id']]['id']=$row['feedback_id'];
		$feedback_list[$row['feedback_id']]['name']=htmlspecialchars($row['feedback_name']);
		$feedback_list[$row['feedback_id']]['content']=htmlspecialchars(filter_badwords($row['feedback_content'],$GLOBALS['config']['site_badwords']));
		$feedback_list[$row['feedback_id']]['time']=date('Y-m-d h:i:s',$row['feedback_time']);
		$feedback_list[$row['feedback_id']]['reply']=htmlspecialchars($row['feedback_reply']);
		$feedback_list[$row['feedback_id']]['address']=get_ip_address($row['feedback_ip']);
		$feedback_list[$row['feedback_id']]['reply_time']=date('Y-m-d h:i:s',$row['feedback_reply_time']);
	}
	$pagebar=pagebar("feedback","",$page_current,$page_size,$count);
}else{
	$pagebar="";
}
$smarty=new smarty();smarty_header();
$smarty->assign('here',here('feedback'));
$smarty->assign('vote',get_vote(6));
$smarty->assign('feedback',$feedback_list);
$smarty->assign('pagebar',$pagebar);
$smarty->display('feedback.html');
?>