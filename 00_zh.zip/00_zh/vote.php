<?php
/**
 * WEEDCMS 投票
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2011年01月04日
*/
require_once('includes/global.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once('includes/front.php');
$action=isset($_GET['action'])?trim($_GET['action']):'';
if($action=='ok'){
	check_request();
	$vote_id=empty($_POST['vote_id'])?'':intval($_POST['vote_id']);
	$res=$db->getall("SELECT log_ip FROM ".$db_prefix."vote_log WHERE vote_id='".$vote_id."'");
	if($res){
		$is_vote=false;
		$ip=get_ip();
		foreach($res as $row){
			if($row['log_ip']==$ip){
				$is_vote=true;
			}
		}
		if($is_vote){
			message(array('text'=>$language['is_voted'],'link'=>''));
		}
	}
	$vote_mode=empty($_POST['vote_mode'])?'':intval($_POST['vote_mode']);
	if($vote_mode==0){
		$item_id=empty($_POST['item_id'])?0:intval($_POST['item_id']);
		$db->query("UPDATE ".$db_prefix."vote_item SET item_count=item_count+1 WHERE item_id='".$item_id."'");
	}else{
		$item_id=empty($_POST['item_id'])?array():$_POST['item_id'];
		foreach($item_id as $id){
			$db->query("UPDATE ".$db_prefix."vote_item SET item_count=item_count+1 WHERE item_id='".$id."'");
		}
	}
	$insert=array();
	$insert['log_ip']=get_ip();
	$insert['log_agent']=addslashes($_SERVER['HTTP_USER_AGENT']);
	$insert['log_time']=time();
	$insert['vote_id']=$vote_id;
	$db->insert($db_prefix."vote_log",$insert);
	$REFERER=$_SERVER['HTTP_REFERER'];
	clear_cache();
	message(array('text'=>$language['vote_is_success'],'link'=>empty($REFERER)?'index.php':$REFERER));
}
?>