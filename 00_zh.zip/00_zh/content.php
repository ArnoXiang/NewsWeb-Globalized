<?php
/**
 * WEEDCMS 内容页
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2011年03月05日
*/
require_once('includes/global.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once('includes/front.php');
$action=empty($_GET['action'])?'':trim($_GET['action']);
if($action=='add'){
	$channel_id=empty($_GET['channel_id'])?0:intval($_GET['channel_id']);
	if($channel_id==0){
		message(array('text'=>$language['parameter_is_lost'],'link'=>''));
	}
	$channel_info=get_channel_info($channel_id);
	if(!check_permissions($channel_info['write_permissions'])){
		if(!check_login()){
			message(array('text'=>$language['please_login'],'link'=>''));
		}
		message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
	}
	$content=array();
	$content['channel_id']=$channel_id;
	$content['id']=0;
	$content['title']='';
	$content['text']='';
	$content['thumb']='';
	$content['password']='';
	$content['link']=array();
	$content['attachment']=array();
	$content['is_best']=0;
	$content['is_comment']=1;
	$content['state']=1;
	$smarty=new smarty();smarty_header();
	$parameters=array();
	$parameters['id']=$channel_id;
	$parameters['mode']='insert';
	$smarty->assign('here',here('member_content',$parameters));
	$smarty->assign('content',$content);
	$smarty->assign('channel_info',$channel_info);
	if(check_have_category($channel_id)){
		$smarty->assign('category_list',category_option_list(0,$channel_id,0));
	}else{
		$smarty->assign('category_list','');
	}
	$smarty->assign('channel_category',get_category($channel_id,0));
	$smarty->assign('mode','insert');
	$smarty->display('content_info.html');
}
if($action=='insert'){
	check_request();
	$channel_id=empty($_POST['channel_id'])?0:intval($_POST['channel_id']);
	if($channel_id==0){
		message(array('text'=>$language['parameter_is_lost'],'link'=>''));
	}
	$channel_info=get_channel_info($channel_id);
	if(!check_permissions($channel_info['write_permissions'])){
		if(!check_login()){
			message(array('text'=>$language['please_login'],'link'=>''));
		}
		message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
	}
	$content_id=empty($_POST['content_id'])?0:intval($_POST['content_id']);
	$content_title=empty($_POST['content_title'])?'':trim(addslashes($_POST['content_title']));
	$content_text=empty($_POST['content_text'])?'':trim(addslashes($_POST['content_text']));
	$content_password=empty($_POST['content_password'])?'':trim(addslashes($_POST['content_password']));
	$category_id=empty($_POST['category_id'])?0:intval($_POST['category_id']);
	if($content_title==''){
		message(array('text'=>$language['content_title_is_empty'],'link'=>''));
	}
	if($content_text==''){
		message(array('text'=>$language['content_text_is_empty'],'link'=>''));
	}
	$content_thumb=upload($_FILES['content_thumb'],false);
	$insert=array();
	$insert['content_title']=$content_title;
	$insert['content_url']='';
	$insert['content_keywords']='';
	$insert['content_description']='';
	$insert['content_text']=$content_text;
	$insert['content_password']=$content_password;
	if(!empty($content_thumb)){
		if($config['image_thumb_open']=='yes'){
			make_thumb(ROOT_PATH.'/uploads/'.$content_thumb,$config['image_thumb_width'],$config['image_thumb_height']);
		}
		$insert['content_thumb']=$content_thumb;
	}
	$insert['content_support']=0;
	$insert['content_against']=0;
	$insert['content_click_count']=0;
	$insert['content_comment_count']=0;
	$insert['content_is_comment']=1;
	$insert['content_is_best']=0;
	$insert['content_state']=1;
	$insert['content_time']=$_SERVER['REQUEST_TIME'];
	$insert['member_id']=isset($_SESSION['member_id'])?$_SESSION['member_id']:0;
	$insert['channel_id']=$channel_id;
	$insert['category_id']=$category_id;
	$db->insert($db_prefix."content",$insert);
	$insert_content_id=$db->insert_id();
	if(!empty($_POST['content_link'])){
		foreach($_POST['content_link'] as $value){
			if(!empty($value)){
				$db->insert($db_prefix."content_link",array('link_url'=>$value,'content_id'=>$insert_content_id));
			}
		}
	}
	$content_attachment=upload($_FILES['content_attachment'],true,get_channel_upload_ext($channel_id));
	foreach($content_attachment as $value){
		if(!empty($value)){
			$db->insert($db_prefix."content_attachment",array('attachment_name'=>$value,'content_id'=>$insert_content_id));
			if($config['image_text_open']=='yes'){
				make_watermark(ROOT_PATH.'/uploads/'.$value,ROOT_PATH.'/images/water.png',$config['image_pos']);
			}
		}
	}
	clear_cache();
	message(array('text'=>$language['content_insert_success'],'link'=>create_uri('channel',array('id'=>$channel_id))));
}
if($action=='edit'){
	$content_id=empty($_GET['content_id'])?0:intval($_GET['content_id']);
	$content_info=get_content_info($content_id);
	if(empty($_SESSION['admin_id'])){
		if(!check_login()){
			message(array('text'=>$language['please_login'],'link'=>''));
		}
		if($content_info['member_id']!=$_SESSION['member_id']){
			message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
		}
	}
	$row=$db->getone("SELECT * FROM ".$db_prefix."content WHERE content_id='".$content_id."'");
	$content=array();
	$content['id']=$row['content_id'];
	$content['title']=$row['content_title'];
	$content['text']=$row['content_text'];
	$content['thumb']=$row['content_thumb'];
	$content['password']=$row['content_password'];
	$content['link']=get_content_link_list($content_id);
	$content['attachment']=get_content_attachment_list($content_id);
	$content['channel_id']=$row['channel_id'];
	$channel_info=get_channel_info($row['channel_id']);
	$smarty=new smarty();smarty_header();
	$parameters=array();
	$parameters['id']=$content_info['channel_id'];
	$parameters['mode']='update';
	$smarty->assign('here',here('member_content',$parameters));
	$smarty->assign('content',$content);
	$smarty->assign('channel_info',$channel_info);
	if(check_have_category($row['channel_id'])){
		$smarty->assign('category_list',category_option_list(0,$row['channel_id'],$row['category_id']));
	}else{
		$smarty->assign('category_list','');
	}
	$smarty->assign('mode','update');
	$smarty->display('content_info.html');
}
if($action=='update'){
	check_request();
	$content_id=empty($_POST['content_id'])?0:intval($_POST['content_id']);
	$content_info=get_content_info($content_id);
	if(empty($_SESSION['admin_id'])){
		if(!check_login()){
			message(array('text'=>$language['please_login'],'link'=>''));
		}
		if($content_info['member_id']!=$_SESSION['member_id']){
			message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
		}
	}
	$content_id=empty($_POST['content_id'])?0:intval($_POST['content_id']);
	$content_title=empty($_POST['content_title'])?'':trim(addslashes($_POST['content_title']));
	$content_text=empty($_POST['content_text'])?'':trim(addslashes($_POST['content_text']));
	$content_password=empty($_POST['content_password'])?'':trim(addslashes($_POST['content_password']));
	$category_id=empty($_POST['category_id'])?0:intval($_POST['category_id']);
	$channel_id=empty($_POST['channel_id'])?0:intval($_POST['channel_id']);
	if($content_title==''){
		message(array('text'=>$language['content_title_is_empty'],'link'=>''));
	}
	if($content_text==''){
		message(array('text'=>$language['content_text_is_empty'],'link'=>''));
	}
	$content_thumb=upload($_FILES['content_thumb']);
	$content_thumb_old=empty($_POST['content_thumb_old'])?'':trim(addslashes($_POST['content_thumb_old']));
	$content_thumb_delete=empty($_POST['content_thumb_delete'])?'':trim(addslashes($_POST['content_thumb_delete']));
	$update=array();
	$update['content_title']=$content_title;
	$update['content_text']=$content_text;
	$update['content_password']=$content_password;
	if(!empty($content_thumb)){
		if(!empty($content_thumb_old)){
			$content_thumb_old=str_replace('..','',$content_thumb_old);
			@unlink(ROOT_PATH."/uploads/".$content_thumb_old);
		}
		if($config['image_thumb_open']=='yes'){
			make_thumb(ROOT_PATH.'/uploads/'.$content_thumb,$config['image_thumb_width'],$config['image_thumb_height']);
		}
		$update['content_thumb']=$content_thumb;
	}
	if(!empty($content_thumb_delete)){
		$content_thumb_delete=str_replace('..','',$content_thumb_delete);
		@unlink(ROOT_PATH."/uploads/".$content_thumb_delete);
		$update['content_thumb']='';
	}
	$update['category_id']=$category_id;
	$db->update($db_prefix."content",$update,"content_id='".$content_id."'");

	if(!empty($_POST['content_link_delete'])){
		foreach($_POST['content_link_delete'] as $value){
			if(!empty($value)){
				$db->delete($db_prefix."content_link","link_id='".$value."'");
			}
		}
	}
	if(!empty($_POST['content_attachment_delete'])){
		foreach($_POST['content_attachment_delete'] as $value){
			if(!empty($value)){
				$row=$db->getone("SELECT attachment_name FROM ".$db_prefix."content_attachment WHERE attachment_id='".$value."'");
				$row['attachment_name']=str_replace('..','',$row['attachment_name']);
				@unlink(ROOT_PATH."/uploads/".$row['attachment_name']);
				$db->delete($db_prefix."content_attachment","attachment_id='".$value."'");
			}
		}
	}
	if(!empty($_POST['content_link'])){
		foreach($_POST['content_link'] as $value){
			if(!empty($value)){
				$db->insert($db_prefix."content_link",array('link_url'=>$value,'content_id'=>$content_id));
			}
		}
	}
	$content_attachment=upload($_FILES['content_attachment'],true);
	foreach($content_attachment as $value){
		if(!empty($value)){
			$db->insert($db_prefix."content_attachment",array('attachment_name'=>$value,'content_id'=>$content_id));
			if($config['image_text_open']=='yes'){
				make_watermark(ROOT_PATH.'/uploads/'.$value,ROOT_PATH.'/images/water.png',$config['image_pos']);
			}
		}
	}
	clear_cache();
	message(array('text'=>$language['content_update_success'],'link'=>create_uri('channel',array('id'=>$content_info['channel_id']))));
}
if($action=='delete'){
	check_request();
	$content_id=empty($_GET['content_id'])?0:intval($_GET['content_id']);
	$content_info=get_content_info($content_id);
	if(empty($_SESSION['admin_id'])){
		if(!check_login()){
			message(array('text'=>$language['please_login'],'link'=>''));
		}
		if($content_info['member_id']!=$_SESSION['member_id']){
			message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
		}
	}
	if(!empty($content_id)){
		$row=$db->getone("SELECT content_thumb FROM ".$db_prefix."content WHERE content_id='".$content_id."'");
		if(!empty($row['content_thumb'])){
			$row['content_thumb']=str_replace('..','',$row['content_thumb']);
			@unlink(ROOT_PATH."/uploads/".$row['content_thumb']);
		}
		$res=$db->getall("SELECT attachment_name FROM ".$db_prefix."content_attachment WHERE content_id='".$content_id."'");
		foreach($res as $row){
			$row['attachment_name']=str_replace('..','',$row['attachment_name']);
			@unlink(ROOT_PATH."/uploads/".$row['attachment_name']);
		}
		$db->delete($db_prefix."content_link","content_id=".$content_id."");
		$db->delete($db_prefix."content_attachment","content_id=".$content_id."");
		$db->delete($db_prefix."content_comment","content_id=".$content_id."");
		$db->delete($db_prefix."content","content_id=".$content_id."");
	}
	clear_cache();
	message(array('text'=>$language['content_delete_success'],'link'=>'channel.php?id='.$content_info['channel_id']));
}
if($action=='get_content'){
	check_request();
	if (isset($_GET['content_id'])){
		$content_id=intval($_GET['content_id']);
	}else{
		exit('ERROR');
	}
	$password=empty($_GET['password'])?'':trim($_GET['password']);
	$content_info=get_content_info($content_id);
	$channel_info=get_channel_info($content_info['channel_id']);
	if($content_info['password']!=$password){
		exit('ERROR');
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('content_info',$content_info);
	$smarty->assign('prev',prev_content($content_info['id'],$content_info['channel_id']));
	$smarty->assign('next',next_content($content_info['id'],$content_info['channel_id']));
	$smarty->display("channel_content_".$channel_info['content_style'].".html");
	exit();
}
if($action=='ajax.support'){
	check_request();
	if (isset($_GET['id'])){
		$content_id=intval($_GET['id']);
	}else{
		exit('ERROR');
	}
	if (!isset($_GET['mode'])&&@$_GET['mode']!='read'){
		$db->query("UPDATE ".$db_prefix."content SET content_support=content_support+1 WHERE content_id=$content_id");
	}
	$row=$db->getone("SELECT content_support FROM ".$db_prefix."content WHERE content_id=$content_id");
	echo($row['content_support']);
	exit();
}
if($action=='ajax.against'){
	check_request();
	if (isset($_GET['id'])){
		$content_id=intval($_GET['id']);
	}else{
		exit('ERROR');
	}
	if (!isset($_GET['mode'])&&@$_GET['mode']!='read'){
		$db->query("UPDATE ".$db_prefix."content SET content_against=content_against+1 WHERE content_id=$content_id");
	}
	$row=$db->getone("SELECT content_against FROM ".$db_prefix."content WHERE content_id=$content_id");
	echo($row['content_against']);
	exit();
}
if (isset($_GET['id'])){
    $content_id=intval($_GET['id']);
}else{
	exit();
}
$content_info=get_content_info($content_id);
if(count($content_info)==0){
	message(array('text'=>$language['content_is_not_exist'],'link'=>''));
}
if($content_info['state']==0){
	message(array('text'=>$language['content_is_lock'],'link'=>''));
}
$channel_info=get_channel_info($content_info['channel_id']);
if(!check_permissions($channel_info['read_permissions'])){
	message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
}
$db->query("UPDATE ".$db_prefix."content SET content_click_count=content_click_count+1 WHERE content_id='".$content_id."'");
set_online(create_uri("content",array('id'=>$content_id)));
$smarty=new smarty();smarty_header($channel_info['cache']!=1?false:true);
$cache_id = sprintf('%X', crc32(md5($content_id."-".(isset($_GET['page'])?intval($_GET['page']):1))));
if (!$smarty->is_cached('content.html',$cache_id)){
	$parameters=array();
	$parameters['id']=$content_id;
	$smarty->assign('here',here('content',$parameters));
	$smarty->assign('vote',get_vote(3));
	$smarty->assign('channel_info',$channel_info);
	$smarty->assign('content_info',$content_info);
	$smarty->assign('hot_content',get_hot_content($content_info['channel_id']));
	$smarty->assign('content_comment',get_content_comment($content_info['channel_id']));
	$smarty->assign('best_content',get_best_content($content_info['channel_id']));
	$smarty->assign('channel_category',get_category($content_info['channel_id'],$content_info['category_id']));
	$smarty->assign('read_permissions',check_permissions($channel_info['read_permissions']));
	$smarty->assign('write_permissions',check_permissions($channel_info['write_permissions']));
	$smarty->assign('comment_permissions',check_permissions($channel_info['comment_permissions']));
	$smarty->assign('content',get_content());
}
$smarty->display('content.html',$cache_id);

function get_content(){
	$GLOBALS['smarty']->assign('content_info',$GLOBALS['content_info']);
	$GLOBALS['smarty']->assign('prev',prev_content($GLOBALS['content_info']['id'],$GLOBALS['content_info']['channel_id']));
	$GLOBALS['smarty']->assign('next',next_content($GLOBALS['content_info']['id'],$GLOBALS['content_info']['channel_id']));
	$out=$GLOBALS['smarty']->fetch("channel_content_".$GLOBALS['channel_info']['content_style'].".html");
	return $out;
}
function prev_content($content_id,$channel_id){
	$row=$GLOBALS['db']->getone("select content_id,content_title,content_url from ".$GLOBALS['db_prefix']."content WHERE content_id>".$content_id." and content_state!=0 and channel_id='".$channel_id."' ORDER BY content_id ASC LIMIT 0,1");
	if($row){
		return array(
			'id'=>$row['content_id'],
			'title'=>$row['content_title'],
			'url'=>!empty($row['content_url'])?$row['content_url']:create_uri("content",array('id'=>$row['content_id'])),
			'target'=>empty($row['content_url'])?true:false
			);
	}else{
		return "";
	}
}
function next_content($content_id,$channel_id){
	$row=$GLOBALS['db']->getone("select content_id,content_title,content_url from ".$GLOBALS['db_prefix']."content WHERE content_id<".$content_id." and content_state!=0 and channel_id='".$channel_id."' ORDER BY content_id DESC LIMIT 0,1");
	if($row){
		return array(
			'id'=>$row['content_id'],
			'title'=>$row['content_title'],
			'url'=>empty($row['content_url'])?create_uri("content",array('id'=>$row['content_id'])):$row['content_url'],
			'target'=>empty($row['content_url'])?true:false
			);
	}else{
		return "";
	}
}
?>