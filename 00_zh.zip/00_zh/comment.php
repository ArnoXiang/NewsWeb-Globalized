<?php
/**
 * WEEDCMS 评论
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月08日
*/
require_once('includes/global.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once('includes/front.php');
$action=isset($_GET['action'])?$_GET['action']:'';
if($action=='content_comment_content'){
	$comment_id=empty($_GET['comment_id'])?'':intval($_GET['comment_id']);
	$row=$db->getone("SELECT comment_content FROM ".$db_prefix."content_comment WHERE comment_id=$comment_id");
	echo($row['comment_content']);
	exit;
}
//插入评论
if($action=='content_comment_insert'){
	check_request();
	$member_id=empty($_SESSION['member_id'])?0:intval($_SESSION['member_id']);
	$content_id=empty($_GET['content_id'])?'':intval($_GET['content_id']);
	$comment_content=empty($_GET['comment_content'])?'':trim($_GET['comment_content']);
	$comment_authcode=empty($_GET['comment_authcode'])?'':addslashes(trim(strtolower($_GET['comment_authcode'])));
	if(empty($comment_authcode)){
		exit('EMPTY:AUTHCODE');
	}
	if($comment_authcode!=@$_SESSION['authcode']){
		$_SESSION['authcode']=false;
		unset($_SESSION['authcode']);
		exit('ERROR:AUTHCODE');
	}
	if(empty($comment_content)){
		exit('EMPTY:CONTENT');
	}
	$insert=array();
	$insert['comment_content']=$comment_content;
	$insert['comment_reply']='';
	$insert['comment_time']=time();
	$insert['comment_ip']=get_ip();
	$insert['comment_agent']=$_SERVER['HTTP_USER_AGENT'];
	if($config['comment_state']=='yes'){
		$insert['comment_state']=0;
	}else{
		$insert['comment_state']=1;
	}

	$insert['content_id']=$content_id;
	$insert['member_id']=$member_id;
	$insert['parent_id']=0;
	$db->insert($db_prefix."content_comment",$insert);
	$db->query("UPDATE ".$db_prefix."content SET content_comment_count=content_comment_count+1 WHERE content_id='".$content_id."'");
	clear_cache();
	if($config['comment_state']=='yes'){
		exit('WAIT');
	}
	exit;
}
//插入评论回复
if($action=='content_comment_reply'){
	check_request();
	$member_id=empty($_SESSION['member_id'])?0:intval($_SESSION['member_id']);
	$content_id=empty($_GET['content_id'])?'':intval($_GET['content_id']);
	$comment_id=empty($_GET['comment_id'])?'':intval($_GET['comment_id']);
	$comment_content=empty($_GET['comment_content'])?'':trim($_GET['comment_content']);
	$insert=array();
	$insert['comment_content']=$comment_content;
	$insert['comment_time']=time();
	$insert['comment_ip']=get_ip();
	$insert['comment_agent']=$_SERVER['HTTP_USER_AGENT'];
	if($config['comment_state']=='no'){
		$insert['comment_state']=0;
	}else{
		$insert['comment_state']=1;
	}
	$insert['content_id']=$content_id;
	$insert['member_id']=$member_id;
	$insert['parent_id']=$comment_id;
	$db->insert($db_prefix."content_comment",$insert);
	$db->query("UPDATE ".$db_prefix."content SET content_comment_count=content_comment_count+1 WHERE content_id='".$content_id."'");
	clear_cache();
	if($config['comment_state']=='yes'){
		exit('WAIT');
	}
	exit;
}
//插入评论更新
if($action=='content_comment_update'){
	check_request();
	$content_id=empty($_GET['content_id'])?0:intval($_GET['content_id']);
	$comment_id=empty($_GET['comment_id'])?0:intval($_GET['comment_id']);
	$comment_content=empty($_GET['comment_content'])?'':trim($_GET['comment_content']);
	$update=array();
	$update['comment_content']=$comment_content;
	$db->update($db_prefix."content_comment",$update,"comment_id=$comment_id");
	clear_cache();
}
//删除评论
if($action=='content_comment_delete'){
	check_request();
	$content_id=empty($_GET['content_id'])?0:intval($_GET['content_id']);
	$comment_id=empty($_GET['comment_id'])?0:intval($_GET['comment_id']);
	$children_count=$db->getcount("SELECT * FROM  ".$db_prefix."comment WHERE parent_id=$comment_id");
	$db->delete($db_prefix."content_comment","comment_id=$comment_id");
	$db->delete($db_prefix."content_comment","parent_id=$comment_id");
	$count=$children_count+1;
	$db->query("UPDATE ".$db_prefix."content SET content_comment_count=content_comment_count-".$count." WHERE content_id='".$content_id."'");
	clear_cache();
}
//评论列表
if($action=='content_comment_list'){
	check_request();
	$content_id=empty($_GET['content_id'])?'':intval($_GET['content_id']);
	$content_info=get_content_info($content_id);
	$channel_info=get_channel_info($content_info['channel_id']);
	$comment_list=array();
	$sql="select * from ".$db_prefix."content_comment where comment_state=1 and parent_id=0 and content_id='".$content_id."'";
	$count=$db->getcount($sql);
	$page_size=$config['comment_size'];
	$page_current=isset($_GET['page'])?intval($_GET['page']):1;
	$page_count		=ceil($count/$page_size);
	$page_start		=$page_current-4;
	$page_end		=$page_current+4;
	if($page_current<5){
		$page_start	=1;
		$page_end	=5;
	}
	if($page_current>$page_count-4){
		$page_start	=$page_count-8;
		$page_end	=$page_count;
	}
	if($page_start<1)$page_start=1;
	if($page_end>$page_count)$page_end=$page_count;
	$pagebar="";


	$rows=$db->getall($sql." order by comment_id asc limit ".(($page_current-1)*$page_size).",".$page_size);
	if($count>0){
			$no=(($page_current-1)*$page_size)+1;
			foreach($rows as $row){
				$comment_list[$row['comment_id']]['no']=$no;
				$comment_list[$row['comment_id']]['id']=$row['comment_id'];
				$comment_list[$row['comment_id']]['content']=encode_comment(filter_badwords($row['comment_content'],$GLOBALS['config']['site_badwords']));
				$comment_list[$row['comment_id']]['reply']=encode_comment(filter_badwords($row['comment_reply'],$GLOBALS['config']['site_badwords']));
				$comment_list[$row['comment_id']]['time']=date("Y-m-d h:i:s",$row['comment_time']);
				$comment_list[$row['comment_id']]['ip']=$row['comment_ip'];
				$comment_list[$row['comment_id']]['ip_address']=get_ip_address($row['comment_ip']);
				$comment_list[$row['comment_id']]['content_id']=$row['content_id'];
				$comment_list[$row['comment_id']]['nickname']=get_member_nickname($row['member_id']);
				$comment_list[$row['comment_id']]['member_id']=$row['member_id'];
				$comment_list[$row['comment_id']]['photo']=get_member_photo($row['member_id']);
				$comment_list[$row['comment_id']]['children']=get_content_comment_children($row['comment_id']);
				$no++;
			}
			$pagebar.="<div class=\"pagebar\">";
			$pagebar.="<span class=\"info\">".$page_current." / ".$page_count."</span>";
			if($page_current!=1){
					$pagebar.="<a href='javascript:get_comment(1)'>&laquo;</a>";
			}
			for($i=$page_start;$i<=$page_end;$i++){
				if($i==$page_current){
					$pagebar.="<span class=\"current\">".$i."</span>";
				}else{
					$pagebar.="<a href='javascript:get_comment(".$i.")'>".$i."</a>";
				}
			}
			if($page_current!=$page_count){
					$pagebar.="<a href='javascript:get_comment(".$page_count.")'>&raquo;</a>";
			}
			$pagebar.="</div>";
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('comment_list',$comment_list);
	$smarty->assign('content_info',$content_info);
	$smarty->assign('comment_permissions',check_permissions($channel_info['comment_permissions']));
	$smarty->assign('pagebar',$pagebar);
	$smarty->display("content_comment.html");
}
?>