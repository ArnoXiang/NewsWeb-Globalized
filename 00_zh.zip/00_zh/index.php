<?php
/**
 * WEEDCMS 首页
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月23日
*/
require_once'includes/global.php';
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once'includes/front.php';
set_online(create_uri("index"));
$smarty=new smarty();smarty_header(true);
$cache_id = sprintf('%X', crc32(ROOT_PATH));
if (!$smarty->is_cached('index.html',$cache_id)){
	$smarty->assign('here',here('index'));
	$smarty->assign('vote',get_vote(1));
	$smarty->assign('link',get_link());
	$smarty->assign('hot_content',get_hot_content());
	$smarty->assign('best_content',get_best_content());
	$smarty->assign('content_comment',get_content_comment());
	$smarty->assign('channel_panel',get_channel_panel());
}
$smarty->display('index.html',$cache_id);
function get_channel_panel(){
    $sql ="SELECT * FROM ".$GLOBALS['db_prefix']."content_channel WHERE channel_state=1 and channel_index=1 ORDER BY channel_sort ASC,channel_id ASC";
    $res = $GLOBALS['db']->getall($sql);
	$array=array();
    foreach ($res AS $row){
		$array[$row['channel_id']]['id']=$row['channel_id'];
		$array[$row['channel_id']]['name']=$row['channel_name'];
		$array[$row['channel_id']]['content']=get_channel_panel_data($row['channel_id']);
		$array[$row['channel_id']]['url']=create_uri('channel',array('id'=>$row['channel_id']));
    }
    return $array;
}
function get_channel_panel_data($channel_id){
	$channel_info=get_channel_info($channel_id);
	$GLOBALS['smarty']->assign('content_list',get_channel_content($channel_id));
	$out=$GLOBALS['smarty']->fetch("channel_index_".$channel_info['index_style'].".html");
	return $out;
}
function get_channel_content($channel_id){
	$channel_info=get_channel_info($channel_id);
    $sql = "SELECT * FROM ".$GLOBALS['db_prefix']."content WHERE content_state=1 and channel_id='".$channel_id."'";
	$sql .= "ORDER BY content_time DESC,content_id DESC LIMIT 0,".$channel_info['index_size'];
    $res = $GLOBALS['db']->getall($sql);
	$array=array();
	if(count($res)>0){
		foreach($res as $row){
			$array[$row['content_id']]['id']=$row['content_id'];
			$array[$row['content_id']]['title']=truncate($row['content_title'],$channel_info['index_truncate']);
			$array[$row['content_id']]['text']=truncate(strip_tags($row['content_text']),$channel_info['index_description_size']);
			$array[$row['content_id']]['thumb']=$row['content_thumb'];
			if(substr($row['content_thumb'],0,4)=='http'){
				$array[$row['content_id']]['thumb_http']=true;
			}else{
				$array[$row['content_id']]['thumb_http']=false;
			}
			$array[$row['content_id']]['time']=date("Y-m-d",$row['content_time']);
			$array[$row['content_id']]['member_photo']=get_member_photo($row['member_id']);
			if(empty($row['content_url'])){
				$array[$row['content_id']]['url']=create_uri('content',array('id'=>$row['content_id']));
				$array[$row['content_id']]['target']=false;
			}else{
				$array[$row['content_id']]['url']=$row['content_url'];
				$array[$row['content_id']]['target']=true;
			}
			$array[$row['content_id']]['category_id']=$row['category_id'];
			$array[$row['content_id']]['category_name']=get_category_name($row['category_id']);
			$array[$row['content_id']]['links']=get_content_link_list($row['content_id']);
			$array[$row['content_id']]['comment_count']=$row['content_comment_count'];
		}
	}
	return $array;
}
function get_link(){
	$array=array();
	$res=$GLOBALS['db']->getall("SELECT * FROM ".$GLOBALS['db_prefix']."link WHERE link_state=1 ORDER BY link_sort ASC,link_id ASC");
	if($res){
		foreach($res as $row){
			$array[$row['link_id']]['id']=$row['link_id'];
			$array[$row['link_id']]['name']=$row['link_name'];
			$array[$row['link_id']]['logo']=$row['link_logo'];
			$array[$row['link_id']]['text']=$row['link_text'];
			$array[$row['link_id']]['url']=$row['link_url'];
		}
	}
	return $array;
}
?>