<?php
/**
 * WEEDCMS 搜索页
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月08日
*/
require_once('includes/global.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
require_once('includes/front.php');
if (empty($_GET['encode'])){//获取编码值
	$string = array_merge($_GET,$_POST);//合并GET和POST重复记录
    $string=search_encode($string);
    header("Location:search.php?encode=$string\n");
    exit;
}else{
	$request=array();
	$request = base64_decode(trim($_GET['encode']));
    if ($request !== false){
        $request = unserialize($request);
        if ($request=== false){
			exit('Access Denied!');
		}
	}
	//过滤一些特殊字符
	$_REQUEST=$request;
	$_REQUEST['keyword']=str_replace("'","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("\"","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("%","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("and","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("select","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("@","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("^","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("&","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("+","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace(",","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("?","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("*","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("/","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("on","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("expression","",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("<iframe","&lt;iframe",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("<script","&lt;script",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace("<","&lt;",$_REQUEST['keyword']);
	$_REQUEST['keyword']=str_replace(">","&gt;",$_REQUEST['keyword']);
	if (empty($_REQUEST['keyword'])){
		 header("Location:./\n");
	}else{
		$keyword=trim($_REQUEST['keyword']);
	}

	$search_list=array();
	$sql="SELECT * FROM ".$GLOBALS['db_prefix']."content WHERE content_state=1 AND content_title like '%".$keyword."%'";
	$page_size=$config['search_size'];
	$page_current=isset($_REQUEST['page'])?intval($_REQUEST['page']):1;
	$count=$db->getcount($sql);
	$result=$db->getall($sql." ORDER BY content_id desc LIMIT ".(($page_current-1)*$page_size).",".$page_size);
	if($count>0){
			$no=$count-(($page_current-1)*$page_size);
			foreach($result as $row){
				$search_list[$row['content_id']]['no']=$no;
				$search_list[$row['content_id']]['id']=$row['content_id'];
				$search_list[$row['content_id']]['channel_id']=$row['channel_id'];
				$search_list[$row['content_id']]['category_id']=$row['category_id'];
				$search_list[$row['content_id']]['nickname']=get_member_nickname($row['member_id']);
				$search_list[$row['content_id']]['title']=str_replace($keyword,"<span style=\"font-weight:bold;color:red\">".$keyword."</span>",$row['content_title']);
				$search_list[$row['content_id']]['time']=date("Y/m/d",$row['content_time']);
				$search_list[$row['content_id']]['click_count']=$row['content_click_count'];
				$search_list[$row['content_id']]['comment_count']=$row['content_comment_count'];
				$search_list[$row['content_id']]['thumb']=$row['content_thumb'];
				$search_list[$row['content_id']]['text']=$row['content_text'];
				$search_list[$row['content_id']]['short_text']=truncate(strip_tags($row['content_text']),200);
				$search_list[$row['content_id']]['password']=$row['content_password'];
				$search_list[$row['content_id']]['is_new']=date("Ymd",$row['content_time'])==date("Ymd")?true:false;
				$no--;
			}
			$page_count		=ceil($count/$page_size);
			$page_start		=$page_current-4;
			$page_end		=$page_current+4;
			if($page_current<5){
				$page_start	=1;
				$page_end	=5;
			}
			if($page_current>$page_count-4){
				$page_start	=$page_count-8;
				$page_end	=$page_count;
			}
			if($page_start<1)$page_start=1;
			if($page_end>$page_count)$page_end=$page_count;

			$string=array();
			$string['keyword']=$keyword;
			$html="";
			$html.="<div class=\"pagebar\">";
			$html.="<span class=\"info\">".$page_current." / ".$page_count."</span>";
			if($page_current!=1){
					$string['page']=1;
					$html.="<a href='search.php?encode=".search_encode($string)."'>&laquo;</a>";
			}
			for($i=$page_start;$i<=$page_end;$i++){
				if($i==$page_current){
					$html.="<span class=\"current\">".$i."</span>";
				}else{
					$string['page']=$i;
					$html.="<a href='search.php?encode=".search_encode($string)."'>".$i."</a>";
				}
			}
			if($page_current!=$page_count){
					$string['page']=$page_count;
					$html.="<a href='search.php?encode=".search_encode($string)."'>&raquo;</a>";
			}
			$html.="</div>";


			$pagebar=$html;
	}else{
			$pagebar="";
	}
	$smarty=new smarty();smarty_header();
	$smarty->assign('here',here('search'));
	$smarty->assign('vote',get_vote(5));
	$smarty->assign('keyword',$keyword);
	$smarty->assign('search_result_empty',str_replace('%keyword%',$keyword,$language['search_result_empty']));
	$smarty->assign('search_list',$search_list);
	$smarty->assign('pagebar',$pagebar);
	$smarty->display('search.html');
}
function search_encode($string){
	$string=str_replace('+','%2b',base64_encode(serialize($string)));//替换+号
	return $string;
}
?>