<?php
/**
 * WEEDCMS 单页
 * ============================================================================
 * 版权所有 2005-2011 WEEDCMS.NET，并保留所有权利。
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * 编码人员：野草
 * 最后修改：2010年12月08日
*/
require_once('includes/global.php');
require_once('includes/front.php');
require_once(ROOT_PATH.'languages/'.$config['site_language'].'/front.php');
if (isset($_GET['id'])){
    $page_id=intval($_GET['id']);
}else{
	exit();
}
$page_info=get_page_info($page_id);
if(count($page_info)==0){
	message(array('text'=>$language['page_is_not_exist'],'link'=>''));
}
//检查是否锁定
if($page_info['state']==0){
	message(array('text'=>$language['page_is_lock'],'link'=>''));
}
//检查访问权限
if(!check_permissions($page_info['permissions'])){
	message(array('text'=>$language['permissions_is_not_enough'],'link'=>''));
}
set_online("page.php?id=".$page_id);
$smarty=new smarty();smarty_header();
$smarty->assign('here',here('page',array('id'=>$page_id)));
$smarty->assign('vote',get_vote(4));
$smarty->assign('page_info',$page_info);
$smarty->assign('page_list',get_page_list());
$smarty->display('page.html');
//获取单页数据
function get_page_info($page_id){
	if(empty($page_id)){
		return array();
	}
	$row=$GLOBALS['db']->getone("SELECT * FROM ".$GLOBALS['db_prefix']."page WHERE page_id='".$page_id."'");
	$array=array();
	$array['id']				=$row['page_id'];
	$array['title']				=$row['page_title'];
	$array['content']			=$row['page_content'];
	$array['permissions']		=$row['page_permissions'];
	$array['state']				=$row['page_state'];
	return $array;
}
//获取单页列表
function get_page_list(){
	$res=$GLOBALS['db']->getall("SELECT * FROM ".$GLOBALS['db_prefix']."page WHERE page_state=1 ORDER BY page_sort ASC,page_id ASC");
	$array=array();
	foreach($res as $row){
		$array[$row['page_id']]['id']		=$row['page_id'];
		$array[$row['page_id']]['title']	=$row['page_title'];
		$array[$row['page_id']]['url']		=create_uri('page',array('id'=>$row['page_id']));
	}
	return $array;
}
?>